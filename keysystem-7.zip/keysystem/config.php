<?php
/**
 * config.php
 * Konfigurasi utama Key System
 */

// Kredensial login panel admin (statis - GANTI kalau perlu di lingkungan produksi)
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'kemplongxd');

// Lokasi file penyimpanan data (JSON sebagai "database")
define('KEYS_FILE', __DIR__ . '/data/keys.json');
define('LOGS_FILE', __DIR__ . '/data/logs.json');
define('RATELIMIT_FILE', __DIR__ . '/data/ratelimit.json');
define('FREE_PRODUCTS_FILE', __DIR__ . '/data/free_products.json');

// Folder tempat menyimpan script yang sudah dienkripsi (di luar akses publik langsung)
define('SCRIPTS_DIR', __DIR__ . '/data/scripts');

// Kunci rahasia untuk enkripsi isi script (AES-256). GANTI dengan string acak panjang!
define('SCRIPT_ENCRYPT_KEY', 'ganti-ini-dengan-string-rahasia-yang-sangat-panjang-dan-acak');

// Default durasi aktif key (dalam detik) jika tidak ditentukan -> 30 hari
define('DEFAULT_DURATION', 60 * 60 * 24 * 30);

// Apakah HWID (Hardware/Device ID) dikunci otomatis saat pemakaian pertama
define('LOCK_HWID_ON_FIRST_USE', true);

// Rate limit untuk endpoint pengambilan script: maksimal N request per IP per WINDOW detik
define('SCRIPT_RATE_LIMIT_MAX', 15);
define('SCRIPT_RATE_LIMIT_WINDOW', 60);

// Rate limit TAMBAHAN per-KEY (independen dari per-IP di atas). Ini menahan
// botnet yang memutar banyak IP berbeda tapi memakai 1 key curian yang sama.
define('KEY_RATE_LIMIT_MAX', 10);
define('KEY_RATE_LIMIT_WINDOW', 60);

// Rate limit khusus untuk script FREE/KEYLESS (per nama produk, karena tidak
// ada key yang bisa dijadikan identifier). Karena free script bisa diakses
// siapa saja, ini jadi garis pertahanan utama supaya tidak gampang di-scrape.
define('FREE_RATE_LIMIT_MAX', 20);
define('FREE_RATE_LIMIT_WINDOW', 60);

// Seberapa sering file ratelimit.json & used_tokens.json dibersihkan
// menyeluruh dari entri kedaluwarsa (detik). PENTING untuk performa: kalau
// dibersihkan di SETIAP request (perilaku lama), server bisa terbebani saat
// trafik ramai karena harus scan seluruh isi file tiap kali. Dengan
// dijadwalkan berkala begini, tiap request cuma mengurus identifier dirinya
// sendiri (murah), dan pembersihan menyeluruh cukup sesekali di background.
define('CLEANUP_INTERVAL', 300); // 5 menit

// File penyimpanan jejak token yang sudah dipakai (untuk single-use token)
define('USED_TOKENS_FILE', __DIR__ . '/data/used_tokens.json');

// File penyimpanan daftar HWID & User yang di-ban secara GLOBAL (lintas
// semua key/produk, termasuk produk free/keyless).
define('BANS_FILE', __DIR__ . '/data/bans.json');

// Berapa banyak entri log terakhir yang ditampilkan di panel admin.
define('LOG_VIEWER_LIMIT', 200);

// Kalau true, satu script_token hanya boleh ditukar SATU KALI. Kalau ada
// yang mencoba pakai token yang sama dua kali (mis. token hasil sadap
// jaringan / dibagikan ke bot lain), permintaan kedua otomatis ditolak.
define('SCRIPT_TOKEN_SINGLE_USE', true);

// Kalau true, loader.php & get_script.php menolak request yang User-Agent-nya
// jelas bukan dari Roblox (curl, python-requests, PostmanRuntime, wget, dst).
// Ini mempersulit bot/stealer generik yang asal curl endpoint tanpa
// menyamar sebagai Roblox. Matikan kalau kamu pakai executor yang UA-nya
// tidak mengandung "Roblox" dan proteksi ini jadi menghalangi pengguna sah.
define('REQUIRE_ROBLOX_USER_AGENT', true);

// Kalau true, loader.php & get_script.php menolak akses non-HTTPS supaya
// key/token tidak bisa disadap di jaringan. DIMATIKAN (false) karena hosting
// belum/tidak pakai SSL. Kalau nanti sudah pasang SSL, sangat disarankan
// ubah ini jadi true lagi untuk keamanan maksimal.
define('REQUIRE_HTTPS', false);

// Berapa lama token akses script berlaku (detik) - lihat get_script.php
define('SCRIPT_TOKEN_TTL', 30);

// Base URL publik tempat folder keysystem ini di-hosting (dipakai untuk
// auto-generate loadstring). Kosongkan ('') untuk auto-deteksi dari domain
// yang sedang diakses, atau isi manual kalau mau dipastikan, misal:
// 'https://domainmu.com/keysystem'
define('BASE_URL', '');

// Apakah script asli di-minify (komentar & baris kosong dibuang) setiap kali
// dikirim ke client, sebagai lapisan tambahan biar tidak mudah dibaca ulang.
define('MINIFY_ON_SERVE', true);

// Apakah stage-1 loader.php WAJIB diberi hwid oleh stub sebelum script asli
// dikeluarkan (2 tahap). Jangan dimatikan kecuali kamu tahu risikonya.
define('REQUIRE_TWO_STAGE_LOAD', true);

// ---- FLOW TICKET (penutup celah "skip loader.php, langsung curl validate.php") ----
// Sebelumnya validate.php/free_token.php bisa dipanggil LANGSUNG (curl +
// User-Agent palsu "Roblox/WinInet") tanpa pernah menyentuh loader.php sama
// sekali, karena kontrak API-nya dokumentasi publik di README. Dengan flow
// ticket, loader.php/loader_free.php menerbitkan tiket pendek (default 15
// detik, sekali-pakai) yang WAJIB disertakan supaya validate.php/
// free_token.php mau mengeluarkan script_token. Ini tidak menghentikan
// pemilik key sah yang niat sekali reverse-engineer seluruh alur, tapi
// menutup jalan pintas untuk bot/stealer generik yang cuma menebak-nebak
// endpoint dari dokumentasi tanpa pernah memanggil loader.php.
define('REQUIRE_FLOW_TICKET', true);
define('FLOW_TICKET_TTL', 15);

// Kalau true, tiket hanya sah dipakai dari IP yang SAMA dengan yang
// menerbitkannya di loader.php (karena kedua request itu terjadi dalam
// hitungan detik dari sesi Roblox yang sama). Matikan kalau hostingmu di
// belakang proxy/load balancer yang bikin IP berubah-ubah antar request.
define('REQUIRE_SAME_IP_FOR_TICKET', true);

// Ukuran maksimal script yang diterima (berlaku sama untuk ketiga metode
// upload: paste, file, dan via link) supaya konsisten dan mendukung script
// ukuran "sedang" (ratusan KB - beberapa MB) tanpa risiko disalahgunakan.
define('SCRIPT_MAX_BYTES', 5 * 1024 * 1024); // 5MB

// Timeout (detik) saat mengambil script lewat URL/link di admin panel.
define('SCRIPT_FETCH_TIMEOUT', 15);

// ---- RESOLVER USERNAME ROBLOX ----
// User ID Roblox yang tersimpan (angka) di-resolve jadi username asli lewat
// API publik Roblox supaya lebih mudah dibaca admin, dengan cache lokal
// supaya tidak perlu manggil API tiap kali halaman admin dibuka.
define('USERNAME_CACHE_FILE', __DIR__ . '/data/username_cache.json');
define('USERNAME_CACHE_TTL', 60 * 60 * 24 * 14); // cache berlaku 14 hari
define('USERNAME_LOOKUP_TIMEOUT', 4); // detik, biar halaman admin tidak lemot kalau API Roblox lambat
define('MAX_USERNAME_LOOKUPS_PER_PAGE', 30); // batasi panggilan API baru per page-load

// Zona waktu
date_default_timezone_set('Asia/Jakarta');

// Header standar untuk semua endpoint API (biar bisa diakses lintas origin)
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
