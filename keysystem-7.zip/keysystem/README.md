# PHP Key System (JSON-based)

Sistem manajemen key/lisensi sederhana ala Luarmor/Jinkie, dibangun dengan PHP native + penyimpanan JSON (tanpa database).

## 📁 Struktur File

```
keysystem/
├── .htaccess             # Matikan directory listing + sembunyikan info server
├── index.php             # Fallback anti-"Index of" di folder root
├── config.php          # Konfigurasi (username/password admin, kunci enkripsi, dll)
├── functions.php        # Semua logika inti (generate, validasi, proteksi script, dll)
├── admin.php             # Halaman LOGIN admin (redirect ke admin_dashboard.php setelah login)
├── admin_auth.php        # Fungsi bersama: cek login, layout header/footer navbar responsif
├── admin_dashboard.php   # Halaman Dashboard/Analytics
├── admin_keys.php        # Halaman manajemen Key
├── admin_scripts.php     # Halaman manajemen Script (upload file/paste + free-keyless)
├── admin_bans.php        # Halaman Ban HWID/User
├── admin_logs.php        # Halaman Log Aktivitas
├── loader.php            # Endpoint STAGE-1 (berkey): dipanggil dari loadstring()
├── loader_free.php       # Endpoint STAGE-1 (FREE/KEYLESS): dipanggil dari loadstring() tanpa key
├── contoh-client.php     # Contoh cara memanggil API dari client (PHP)
├── assets/
│   ├── .htaccess        # Matikan directory listing folder assets/
│   ├── index.php        # Fallback anti-"Index of" folder assets/
│   └── admin.css        # Stylesheet responsif bersama semua halaman admin
├── api/
│   ├── .htaccess        # Matikan directory listing folder api/
│   ├── index.php        # Fallback anti-"Index of" folder api/
│   ├── validate.php     # Endpoint publik (berkey): cek key valid + terbitkan script_token
│   ├── free_token.php   # Endpoint publik (FREE/KEYLESS): terbitkan script_token tanpa key
│   ├── get_script.php   # Endpoint STAGE-2 (dipakai berkey maupun free): tukar token -> isi script asli
│   └── generate.php     # Endpoint admin: generate key via API
└── data/
    ├── .htaccess          # Blokir akses total + matikan directory listing
    ├── index.php          # Fallback anti-"Index of" folder data/
    ├── keys.json          # "Database" key (dibuat otomatis)
    ├── free_products.json # Daftar produk yang ditandai free/keyless (dibuat otomatis)
    ├── bans.json          # Daftar HWID/User yang di-ban global (dibuat otomatis)
    ├── logs.json          # Log aktivitas (dibuat otomatis)
    ├── ratelimit.json     # Data rate limiting (dibuat otomatis)
    ├── used_tokens.json   # Jejak token sekali-pakai (dibuat otomatis)
    ├── script_index.json  # Daftar produk yang punya script (dibuat otomatis)
    └── scripts/           # Script asli, tersimpan terenkripsi AES-256 (dibuat otomatis, htaccess+index.php otomatis juga)
```

## Panel Admin (Multi-halaman, Responsif)

Panel admin sekarang terpisah per fitur, masing-masing punya halaman sendiri (bukan satu halaman panjang lagi), dengan navbar yang otomatis jadi menu hamburger di layar sempit (HP):

| Halaman | URL | Isi |
|---|---|---|
| Login | `admin.php` | Form login (username/password) |
| Dashboard | `admin_dashboard.php` | Statistik: total key per status, jumlah produk script, produk free/keyless, total ban, aktivitas hari ini/7 hari, 10 event teratas — dihitung dari data sistem sendiri (tanpa tracker pihak ketiga) |
| Keys | `admin_keys.php` | Generate key baru + daftar & aksi (reset HWID/User, revoke, extend, hapus) |
| Scripts | `admin_scripts.php` | Upload script lewat 3 cara: **Upload File** (default — cukup nama produk + pilih file, tanpa copy-paste), **Upload via Link** (server ambil isi file dari URL), atau **Tempel Kode** (opsi lanjutan) + toggle Free/Keyless |
| Bans | `admin_bans.php` | Ban/unban HWID & User secara global — tinggal pilih dari saran (tanpa ketik manual) atau klik tombol Ban langsung dari halaman Keys; User ditampilkan sebagai **username Roblox**, bukan angka |
| Logs | `admin_logs.php` | Viewer log aktivitas dengan filter |



1. Upload semua file ke hosting/server yang mendukung PHP 7.4+ dengan ekstensi `openssl` aktif (biasanya sudah aktif secara default).
2. Buka `config.php`, ganti `ADMIN_USERNAME` / `ADMIN_PASSWORD` dan `SCRIPT_ENCRYPT_KEY`.
3. Pastikan folder `data/` bisa ditulis oleh PHP (`chmod 755 data`, atau `775` jika perlu).
4. (Opsional) Isi `BASE_URL` di `config.php` kalau auto-deteksi domain tidak akurat di hosting kamu.
5. Buka `admin.php` di browser untuk login ke panel admin.

## 🔑 Cara Kerja

### 1. Generate Key (via Admin Panel)
Buka `admin_keys.php` → login (`admin` / `kemplongxd` secara default, akan diarahkan otomatis) → isi form "Buat Key Baru" (nama produk, durasi hari **atau centang Permanent**, **Maks. HWID/Perangkat**, **Maks. User/Akun**, catatan) → klik Generate.

- **Maks. HWID** = jumlah PERANGKAT berbeda yang boleh memakai key ini.
- **Maks. User** = jumlah AKUN/USER berbeda yang boleh memakai key ini — independen dari HWID. Berguna kalau mau, misalnya, satu key dipakai 1 akun tapi boleh login dari beberapa perangkat, atau sebaliknya.

Setelah key dibuat, panel otomatis menampilkan **key** dan **loadstring siap-pakai**, misalnya:
```lua
loadstring(game:HttpGet("https://domainmu.com/keysystem/loader.php?key=ABCD-1234-EFGH-5678"))()
```
Loadstring ini juga muncul di kolom "Loadstring" untuk setiap key lama di tabel bawahnya (tinggal klik Copy).

### 2. Generate Key (via API, misal untuk otomatisasi setelah pembayaran)
```bash
curl -X POST https://domainmu.com/keysystem/api/generate.php \
  -H "Content-Type: application/json" \
  -d '{
    "admin_password": "password_admin_kamu",
    "product": "MyScript",
    "duration_days": 30,
    "note": "order #123",
    "max_hwid": 1,
    "max_user": 1
  }'
```
Response-nya sudah menyertakan field `loadstring` siap pakai. Kirim `"duration_days": 0` untuk key permanent/lifetime.

### 3. Upload Script (via Admin Panel)
Di `admin_scripts.php` ada 3 cara upload script, semuanya dibatasi ukuran maksimal (`SCRIPT_MAX_BYTES`, default 5MB) supaya mendukung script ukuran sedang tanpa risiko disalahgunakan:
- **Upload File** (default, tab pertama) → isi nama produk (harus sama persis dengan `product` di key) + pilih file `.lua`/`.luau`/`.txt` → Upload. Tidak perlu copy-paste sama sekali.
- **Upload via Link** → isi nama produk + tempel URL publik (http/https) yang mengarah ke file script (mis. raw GitHub, pastebin raw, dll) → server yang mengambil isinya sendiri. URL ke alamat internal/lokal (localhost, 127.0.0.1, IP privat, endpoint metadata cloud) otomatis ditolak untuk mencegah SSRF.
- **Tempel Kode (Lanjutan)** → cara manual, isi nama produk + tempel source code langsung.

Ketiganya langsung dienkripsi AES-256 saat disimpan, dan semua format Lua/Luau (`.lua` maupun `.luau`) didukung sama saja karena disimpan sebagai teks mentah — tidak ada parsing sintaks khusus.

### 4. Alur Eksekusi di Sisi Pengguna
Pengguna tinggal tempel **loadstring** ke executor mereka. Di baliknya, terjadi 2 tahap otomatis:
1. `loader.php?key=...` (stage-1) dipanggil oleh `loadstring()` → server precek key (status/expired), lalu balas **stub Lua kecil** (bukan script asli).
2. Stub tsb dijalankan di sisi client → menghitung `hwid` (perangkat) dan `userid` (akun) asli → panggil `api/validate.php` (dapat `script_token` sekali-pakai, berlaku ±30 detik) → tukar token itu ke `api/get_script.php?raw=1` → baru script asli (sudah di-watermark) di-`loadstring()` dan dijalankan.

Batas `max_hwid` dan `max_user` dicek terpisah: key bisa ditolak karena kehabisan slot perangkat meskipun slot user masih ada, atau sebaliknya. Admin bisa reset masing-masing lewat tombol **Reset HWID** / **Reset User** di panel tanpa perlu bikin key baru.

### 5. Script Free / Keyless (Tanpa Key)
Kalau ada produk yang mau dibagikan gratis tanpa key sama sekali, tapi source-nya tetap tidak mau bisa di-`curl` bebas:

1. Upload script-nya seperti biasa di bagian "Kelola Script".
2. Di tabel bawahnya, klik tombol **"Jadikan Free/Keyless"** pada baris produk tsb.
3. Setelah aktif, akan muncul input **Loadstring** khusus untuk produk itu, bentuknya:
   ```lua
   loadstring(game:HttpGet("https://domainmu.com/keysystem/loader_free.php?product=MyFreeScript"))()
   ```

Alurnya sama persis dengan yang berkey (2 tahap, rate limit, token sekali-pakai, watermark) — bedanya cuma tidak ada validasi key: `loader_free.php` (stage-1) → `api/free_token.php` (terbitkan token) → `api/get_script.php?raw=1` (stage-2, tukar token jadi script asli). Watermark untuk script free berisi jejak HWID pemakai (bukan key, karena memang tidak ada), tetap berguna untuk melacak siapa yang menyebarluaskan ulang.

Klik **"Jadikan Wajib Key"** kapan saja untuk mencabut status free — begitu dicabut, loadstring free yang sudah beredar otomatis berhenti berfungsi.

### 6. Monitoring Log
Buka `admin_dashboard.php` untuk ringkasan/analytics (total key per status, jumlah script, free/keyless, ban, grafik batang aktivitas & event teratas). Untuk log mentah lengkap, buka `admin_logs.php` — menampilkan histori terbaru (default 200 entri, atur lewat `LOG_VIEWER_LIMIT` di config): validasi key sukses/gagal, fetch script, percobaan yang ditolak (rate limit, UA mencurigakan, ban), generate key, ban/unban, dan sebagainya. Bisa difilter lewat dropdown (Semua / Gagal saja / Sukses saja / Free-Keyless saja / Ban-Unban saja / Generate key saja).

### 7. Ban HWID / User (Global)
Beda dengan batas per-key (Maks. HWID/User yang cuma berlaku untuk 1 key tertentu), halaman **`admin_bans.php`** ("Bans" di navbar) memblokir sebuah perangkat atau akun **lintas semua key dan produk** — termasuk produk Free/Keyless. Berguna untuk memblokir orang yang ketahuan curang/redistribusi script, apa pun key yang dia coba pakai berikutnya.

- Isi kolom HWID atau User ID (bisa dilihat dari kolom HWID/User di tabel key, atau dari Log Aktivitas) + alasan opsional → klik Ban.
- Perangkat/akun yang di-ban langsung ditolak di titik paling awal (sebelum sempat menghabiskan slot HWID/User di key manapun).
- Klik **Unban** kapan saja untuk mencabut.

## 🛡️ Proteksi Script (Anti-Pencurian)

1. **Flow ticket, diikat ke IP + context spesifik (menutup celah "skip loader.php" DAN celah "tiket key A dipakai untuk key B").** Sebelumnya, orang yang tahu kontrak API dari dokumentasi ini bisa curl LANGSUNG ke `api/validate.php` atau `api/free_token.php` dengan User-Agent Roblox palsu, tanpa pernah menyentuh `loader.php`/`loader_free.php` sama sekali — cukup untuk dapat `script_token`. Sekarang `loader.php`/`loader_free.php` menerbitkan **tiket sekali-pakai berumur sangat pendek (default 15 detik, `FLOW_TICKET_TTL`)** yang WAJIB disertakan sebelum `validate.php`/`free_token.php` mau mengeluarkan `script_token`. Tiket ini diikat ke: (a) IP yang menerbitkannya (`REQUIRE_SAME_IP_FOR_TICKET`), (b) **key/produk spesifik yang sedang divalidasi** — jadi tiket yang diterbitkan untuk key A tidak bisa "dipinjam" untuk memvalidasi key B curian meski dari IP yang sama, dan (c) hanya sah dipakai satu kali. Diatur lewat `REQUIRE_FLOW_TICKET` di config.
2. **Disimpan terenkripsi (AES-256-CBC)** di `data/scripts/*.enc`, dengan nama file di-hash — tidak menebak nama produk. Folder ini juga diblokir akses langsung via `.htaccess`.
3. **Alur 2-tahap (seperti cara kerja Luarmor asli).** URL yang dibagikan ke pengguna (`loader.php?key=...`) **tidak pernah** langsung berisi script — hanya stub kecil. Script asli baru diambil lewat request kedua yang terjadi otomatis di runtime, setelah HWID asli pengguna diketahui dan divalidasi.
   - Kalau URL loadstring itu sendiri dicoba dibuka orang lain di browser/curl, mereka cuma dapat stub Lua pendek, bukan isi script.
   - `api/get_script.php` **tidak menerima key secara langsung** — wajib token sekali-pakai (`script_token`) yang hanya terbit setelah key+HWID lolos di `validate.php` **dan** flow ticket dari `loader.php` valid.
4. **Validasi ulang saat tukar token** — kalau key sudah direvoke/expired setelah token terbit, pengambilan script otomatis ditolak.
5. **Token sekali-pakai (single-use).** Begitu `script_token` dipakai satu kali untuk mengambil script, token itu langsung "terbakar" — percobaan pakai ulang (misal token hasil sadap traffic/dibagikan ke bot lain) otomatis ditolak dengan pesan "Token sudah pernah digunakan." (`SCRIPT_TOKEN_SINGLE_USE` di config).
6. **Watermark otomatis.** Setiap script yang keluar disisipi jejak unik dari key+HWID pemakainya. Kalau ada yang menyebarluaskan ulang script itu, kamu bisa lihat jejaknya di baris pertama untuk tahu key mana yang bocor, lalu langsung revoke key tersebut lewat panel admin.
7. **Minify otomatis** (buang komentar & baris kosong) setiap kali script dikirim, sebagai lapisan tambahan (`MINIFY_ON_SERVE` di config).
8. **Deteksi User-Agent bukan-Roblox.** `validate.php`, `free_token.php`, `loader.php`, `loader_free.php`, dan `get_script.php` menolak request yang User-Agent-nya jelas dari tool umum (curl, wget, python-requests, PostmanRuntime, Insomnia, dll) — bukan dari Roblox (`REQUIRE_ROBLOX_USER_AGENT`). **Catatan:** ini heuristik, gampang dilewati kalau seseorang secara sengaja menyamar (`curl -A "Roblox/WinInet"`) — makanya lapisan #1 (flow ticket) yang jadi pertahanan utama, bukan cek UA ini.
9. **Ban global HWID/User** (lihat panel admin) — memblokir perangkat/akun tertentu lintas semua key/produk secepatnya sebelum mereka bisa mendapat token apa pun.
10. **HTTPS opsional** (`REQUIRE_HTTPS`, default **dimatikan** karena banyak hosting belum pasang SSL) — di `loader.php`, `loader_free.php`, `api/free_token.php` & `get_script.php`. Kalau hosting kamu sudah punya SSL, sangat disarankan set `REQUIRE_HTTPS` ke `true` supaya key/token tidak bisa disadap di jaringan (mis. WiFi publik/proxy tidak terenkripsi).
11. **Rate limiting berlapis**: per-IP DAN per-KEY/per-PRODUK di `validate.php`, `free_token.php`, `loader.php`, `loader_free.php`, dan `get_script.php`. Limit per-key/produk penting karena limit per-IP saja bisa dilewati botnet yang memutar banyak IP berbeda tapi memakai 1 key curian yang sama.

**Batasan yang perlu dipahami:** flow ticket menutup celah "curl API langsung tanpa pernah lewat loader.php", tapi **tidak** dan **tidak bisa** mencegah pemilik key sah yang benar-benar niat membongkar seluruh alur (loader.php → validate.php → get_script.php) lalu mereplikasinya sendiri dengan curl — ini adalah batasan mendasar dari sistem apa pun yang kontennya pada akhirnya harus sampai ke perangkat pengguna (sama seperti keterbatasan DRM pada umumnya: kalau bisa dijalankan, secara prinsip bisa "disalin" oleh yang menjalankannya). Yang bisa dilakukan sistem ini adalah membuat prosesnya **jauh lebih rumit untuk direplikasi** (harus reverse-engineer 3 request berurutan, tiket sekali-pakai+terikat IP+TTL 15 detik, bukan sekadar tebak 1-2 endpoint dari dokumentasi) dan **mudah dilacak/ditindak** kalau kejadian (lewat watermark unik + revoke key + ban HWID/User global), bukan menjamin mustahil 100%.

## 🔒 Fitur

- Format key acak `XXXX-XXXX-XXXX-XXXX` (tanpa karakter ambigu).
- Durasi fleksibel: harian atau **Permanent/lifetime** (checkbox khusus di admin panel maupun `"duration_days": 0` di API).
- Auto-generate **loadstring** setiap kali key dibuat (admin panel & API).
- **HWID lock** (maks. perangkat) dan **User lock** (maks. akun) — dua batas independen yang bisa diatur terpisah saat generate key, masing-masing bisa direset sendiri-sendiri.
- Status key: `active`, `revoked`, `paused`, `expired`.
- Multi-produk: satu sistem bisa melayani banyak script/produk berbeda (field `product`).
- Perpanjang masa aktif (extend) tanpa perlu bikin key baru.
- Log seluruh aktivitas (generate, validasi sukses/gagal, reset, fetch script, dll) di `data/logs.json`.
- Semua data tersimpan sebagai JSON, tidak perlu MySQL — cocok untuk shared hosting sederhana.

## Performa & Beban Server

Sistem ini pakai file JSON sebagai "database" (bukan MySQL) supaya ringan dan jalan di hosting sederhana. Beberapa optimasi yang sudah diterapkan supaya tidak membebani VPS/server saat trafik ramai:

- **Rate-limit & token sekali-pakai dibersihkan berkala, bukan tiap request.** Sebelumnya, tiap kali ada yang validasi key/ambil script, sistem men-scan **seluruh** daftar IP/key/produk yang sedang aktif untuk buang yang kedaluwarsa — kalau ada ratusan/ribuan identifier aktif, ini jadi beban CPU/IO nyata karena terjadi di **setiap** request. Sekarang tiap request cuma mengurus datanya sendiri (murah), dan pembersihan menyeluruh dijadwalkan tiap `CLEANUP_INTERVAL` detik (default 5 menit) di config. Pada simulasi trafik 10.000 request/jam dengan 500 identifier aktif, ini memangkas ~99% operasi scan.
- **Cek ban HWID/User digabung jadi 1x baca file**, bukan 2x terpisah.
- **Log dibatasi otomatis** ke 2000 entri terakhir (`ks_log()`), jadi file log tidak membengkak tanpa batas walau sistem dipakai lama.
- **Resolusi username Roblox** (halaman admin) dibatasi maksimal `MAX_USERNAME_LOOKUPS_PER_PAGE` panggilan API baru per page-load, dan **tidak pernah** terjadi di jalur validasi key/pengambilan script (jadi tidak menambah lag ke pemain).

**Rekomendasi tambahan untuk hosting/VPS:**
- Aktifkan **PHP OPcache** kalau belum (biasanya tinggal di-enable lewat panel hosting/`php.ini`) — ini peningkatan performa PHP paling signifikan dan berlaku universal, karena PHP tidak perlu parse ulang source code di setiap request.
- Untuk trafik SANGAT tinggi (ribuan pemain aktif bersamaan), sistem file JSON pada akhirnya akan jadi bottleneck karena setiap tulis-data mengunci seluruh file (`flock`) sehingga penulisan diserialisasi. Kalau sudah di titik ini, pertimbangkan migrasi `keys.json`/`ratelimit.json` ke SQLite atau MySQL — di luar cakupan sistem ini saat ini, tapi strukturnya (semua akses data lewat `functions.php`) dirancang supaya migrasi semacam itu tidak perlu mengubah banyak kode di luar file itu.
- Taruh `data/` di disk SSD (default di hampir semua VPS modern) untuk I/O yang lebih cepat.



- **Resolver username Roblox** (halaman Keys & Bans) memanggil API publik `users.roblox.com`, di-cache lokal 14 hari (`USERNAME_CACHE_FILE`/`USERNAME_CACHE_TTL`) supaya halaman admin tidak lambat. Kalau API Roblox sedang down/lambat, sistem otomatis fallback tampilkan angka UserId mentah — tidak akan error/blank. Butuh ekstensi cURL aktif (sama seperti fitur Upload via Link).

- **Wajib** ganti `ADMIN_USERNAME` / `ADMIN_PASSWORD` di `config.php` sebelum online (default saat ini: `admin` / `kemplongxd`).
- **Wajib** ganti `SCRIPT_ENCRYPT_KEY` di `config.php` dengan string acak panjang milikmu sendiri — token akses script & enkripsi script sama-sama bergantung pada key ini.
- `REQUIRE_HTTPS` di config saat ini **dimatikan (`false`)** secara default supaya tetap jalan di hosting tanpa SSL. Ini artinya key/token bisa disadap kalau jaringan tidak aman. **Sangat disarankan** aktifkan (`true`) begitu hosting kamu sudah pasang SSL/HTTPS (banyak hosting menyediakan gratis lewat Let's Encrypt).
- Kalau setelah upload loadstring tiba-tiba gagal terus padahal key benar, cek dulu apakah executor/klien yang kamu pakai mengirim User-Agent yang mengandung "Roblox" — kalau tidak, `REQUIRE_ROBLOX_USER_AGENT` di config perlu dimatikan (`false`) untuk klien tersebut.
- Kalau loadstring sering gagal dengan pesan terkait "akses tidak sah"/token, kemungkinan hosting kamu di belakang proxy/load balancer yang membuat IP request loader.php dan validate.php berbeda-beda (padahal berasal dari sesi Roblox yang sama). Coba matikan `REQUIRE_SAME_IP_FOR_TICKET` (jadi `false`) di config. Kalau tetap gagal, `FLOW_TICKET_TTL` (default 15 detik) mungkin perlu diperpanjang sedikit kalau koneksi hosting-mu lambat.
- Sebaiknya taruh folder `data/` di luar `public_html` (web root) kalau hosting mendukung, supaya `keys.json` dan script terenkripsi tidak bisa diakses langsung lewat URL. Kalau tidak memungkinkan, `.htaccess` di dalam `data/` dan `data/scripts/` sudah otomatis dibuat kompatibel Apache lama maupun baru (`Require all denied` + fallback `Deny from all`) — kalau pakai Nginx/LiteSpeed, tambahkan blokir setara di konfigurasi server.
- **Directory listing ("Index of /") sudah dimatikan** (`Options -Indexes`) di semua folder (`/`, `api/`, `data/`, `data/scripts/`), dilengkapi file `index.php` kosong sebagai cadangan kalau hosting mengabaikan `.htaccess`. Kalau kamu tetap melihat halaman "Index of /" di suatu folder setelah upload, kemungkinan hosting-mu men-disable `.htaccess` sepenuhnya (`AllowOverride None`) — hubungi support hosting untuk mengaktifkannya, atau pastikan modul `mod_rewrite`/`mod_authz_core` aktif.
- `hwid` di stub bawaan memakai `RbxAnalyticsService:GetClientId()` — ID yang persisten per perangkat/instalasi Roblox, TIDAK berubah walau pemain rejoin atau pindah server (fallback ke UserId kalau API itu tidak tersedia). `userid` memakai UserId Roblox saja. **Catatan riwayat:** versi sebelumnya sempat memakai kombinasi UserId+JobId untuk hwid, yang menyebabkan bug — JobId berubah tiap sesi/rejoin sehingga perangkat yang sama dianggap "perangkat baru" terus dan cepat kehabisan kuota `max_hwid`. Sudah diperbaiki di versi ini.
- **Upload via Link** butuh ekstensi **cURL** aktif di PHP (hampir selalu aktif secara default di hosting manapun). URL dicek dulu supaya bukan alamat internal/privat (anti-SSRF) sebelum diambil.
- Kalau upload file gagal terus padahal ukurannya di bawah `SCRIPT_MAX_BYTES`, kemungkinan `php.ini` di hosting kamu punya `upload_max_filesize` atau `post_max_size` yang lebih kecil (default banyak hosting: 2MB). `SCRIPT_MAX_BYTES` di `config.php` cuma membatasi dari sisi aplikasi — batas PHP-level itu perlu diubah lewat panel hosting/`php.ini` kamu sendiri kalau perlu upload file lebih besar. Untuk file besar, opsi **Upload via Link** biasanya lebih andal karena tidak terkena batas upload PHP tersebut.
- **Kompatibilitas executor:** stub loadstring memakai API paling universal (`game:HttpGet`, `HttpService:JSONDecode`, `loadstring`) yang didukung hampir semua executor (termasuk executor mobile seperti Medium, Delta, Arceus X, dll). Bagian yang lebih jarang didukung (`RbxAnalyticsService:GetClientId()` untuk HWID) dibungkus `pcall` dengan fallback otomatis ke UserId, jadi tetap jalan meski executor tertentu tidak mendukungnya — hanya proteksi per-perangkatnya jadi sedikit lebih longgar (turun ke per-akun) di executor tersebut.
