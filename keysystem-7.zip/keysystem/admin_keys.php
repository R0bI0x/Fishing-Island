<?php
/**
 * admin_keys.php
 * Halaman manajemen key: generate key baru (durasi/permanent, maks
 * HWID/User), daftar semua key beserta loadstring siap-pakai, dan aksi
 * per key (reset HWID, reset User, revoke/aktifkan, extend, hapus).
 */
require_once __DIR__ . '/admin_auth.php';
ks_admin_require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $product   = trim($_POST['product'] ?? 'default');
        $permanent = isset($_POST['permanent']);
        $days      = (float)($_POST['days'] ?? 30);
        $note      = trim($_POST['note'] ?? '');
        $maxHwid   = (int)($_POST['max_hwid'] ?? 1);
        $maxUser   = (int)($_POST['max_user'] ?? 1);
        $duration  = $permanent ? 0 : (int)($days * 86400); // 0 = permanent/lifetime
        $newEntry  = ks_create_key($product, $duration, $note, $maxHwid, $maxUser);
        // Simpan sementara di session supaya bisa ditampilkan setelah redirect
        $_SESSION['ks_last_created'] = $newEntry['key'];
    } elseif ($action === 'reset_hwid') {
        $targetKey = trim($_POST['key'] ?? '');
        if ($targetKey !== '') ks_reset_hwid($targetKey);
    } elseif ($action === 'reset_users') {
        $targetKey = trim($_POST['key'] ?? '');
        if ($targetKey !== '') ks_reset_users($targetKey);
    } elseif ($action === 'revoke') {
        $targetKey = trim($_POST['key'] ?? '');
        if ($targetKey !== '') ks_set_status($targetKey, 'revoked');
    } elseif ($action === 'activate') {
        $targetKey = trim($_POST['key'] ?? '');
        if ($targetKey !== '') ks_set_status($targetKey, 'active');
    } elseif ($action === 'delete') {
        $targetKey = trim($_POST['key'] ?? '');
        if ($targetKey !== '') ks_delete_key($targetKey);
    } elseif ($action === 'extend') {
        $targetKey = trim($_POST['key'] ?? '');
        $extraDays = (float)($_POST['extra_days'] ?? 0);
        if ($targetKey !== '') ks_extend_key($targetKey, (int)($extraDays * 86400));
    }

    header('Location: admin_keys.php');
    exit;
}

$keys = ks_read_keys()['keys'];
usort($keys, function ($a, $b) {
    return $b['created_at'] <=> $a['created_at'];
});

// Ambil & bersihkan info key yang baru saja dibuat (kalau ada), untuk
// ditampilkan sebagai box "key + loadstring siap pakai".
$lastCreatedKey = null;
$lastCreatedLoadstring = null;
if (!empty($_SESSION['ks_last_created'])) {
    $lastCreatedKey = $_SESSION['ks_last_created'];
    $lastCreatedLoadstring = ks_build_loadstring($lastCreatedKey);
    unset($_SESSION['ks_last_created']);
}

ks_admin_header('keys', 'Keys');
?>

<div class="card">
  <h3 style="margin-top:0">Buat Key Baru</h3>
  <?php if ($lastCreatedKey): ?>
  <div style="background:#0f1115; border:1px solid var(--green); border-radius:8px; padding:14px; margin-bottom:16px;">
    <div style="color:var(--green); font-weight:600; font-size:13px; margin-bottom:8px;">Key berhasil dibuat!</div>
    <label>Key</label>
    <div style="display:flex; gap:6px; margin-bottom:10px;">
      <input type="text" readonly value="<?= htmlspecialchars($lastCreatedKey) ?>" style="margin-bottom:0" id="lastKeyInput">
      <button type="button" class="small" onclick="copyField('lastKeyInput')">Copy</button>
    </div>
    <label>Loadstring (siap tempel ke executor)</label>
    <div style="display:flex; gap:6px;">
      <input type="text" readonly value="<?= htmlspecialchars($lastCreatedLoadstring) ?>" style="margin-bottom:0" id="lastLoadstringInput">
      <button type="button" class="small" onclick="copyField('lastLoadstringInput')">Copy</button>
    </div>
  </div>
  <?php endif; ?>
  <form method="post" class="grid">
    <input type="hidden" name="action" value="create">
    <div>
      <label>Nama Produk / Script</label>
      <input type="text" name="product" placeholder="MyScript" required>
    </div>
    <div>
      <label>Durasi (hari)</label>
      <input type="number" step="0.1" name="days" id="daysInput" value="30" required>
    </div>
    <div>
      <label>Maks. HWID / Perangkat Terikat</label>
      <input type="number" name="max_hwid" value="1" min="1" required>
    </div>
    <div>
      <label>Maks. User / Akun Terikat</label>
      <input type="number" name="max_user" value="1" min="1" required>
    </div>
    <div>
      <label>Catatan (opsional)</label>
      <input type="text" name="note" placeholder="nama pembeli, dll">
    </div>
    <div style="display:flex; align-items:center; gap:6px; padding-top:18px;">
      <input type="checkbox" name="permanent" id="permanentCheckbox" style="width:auto; margin:0;" onchange="document.getElementById('daysInput').disabled = this.checked;">
      <label for="permanentCheckbox" style="margin:0; color:var(--text); font-size:13px;">Permanent (lifetime)</label>
    </div>
    <div style="align-self:end">
      <button type="submit">Generate Key</button>
    </div>
  </form>
</div>

<div class="card">
  <h3 style="margin-top:0">Daftar Key (<?= count($keys) ?>)</h3>
  <div class="table-responsive">
  <table>
    <tr>
      <th>Key</th><th>Produk</th><th>Status</th><th>Expired</th>
      <th>HWID</th><th>User</th><th>Catatan</th><th>Loadstring</th><th>Aksi</th>
    </tr>
    <?php foreach ($keys as $k): ?>
    <?php
      // Kompatibilitas mundur untuk key lama yang belum punya field max_user/users
      $maxUser = $k['max_user'] ?? 1;
      $users   = $k['users'] ?? [];
      $rowId   = 'ls_' . md5($k['key']);
    ?>
    <tr>
      <td class="key-str"><?= htmlspecialchars($k['key']) ?></td>
      <td><?= htmlspecialchars($k['product']) ?></td>
      <td><span class="badge <?= htmlspecialchars($k['status']) ?>"><?= htmlspecialchars($k['status']) ?></span></td>
      <td><?= $k['expires_at'] === 0 ? 'Lifetime' : ks_fmt_date($k['expires_at']) ?></td>
      <td class="hwid-list">
        <?php if (empty($k['hwids'])): ?>
          0/<?= $k['max_hwid'] ?>
        <?php else: ?>
        <details>
          <summary><?= count($k['hwids']) ?>/<?= $k['max_hwid'] ?></summary>
          <div class="hwid-detail">
            <?php foreach ($k['hwids'] as $h): ?>
            <div class="id-row">
              <span class="id-row-text"><?= htmlspecialchars($h) ?></span>
              <form method="post" action="admin_bans.php" onsubmit="return confirm('Ban HWID ini secara global?')">
                <input type="hidden" name="action" value="ban_hwid">
                <input type="hidden" name="ban_hwid" value="<?= htmlspecialchars($h) ?>">
                <input type="hidden" name="ban_reason" value="Dari halaman Keys (<?= htmlspecialchars($k['key']) ?>)">
                <button type="submit" class="small red">Ban</button>
              </form>
            </div>
            <?php endforeach; ?>
          </div>
        </details>
        <?php endif; ?>
      </td>
      <td class="hwid-list">
        <?php if (empty($users)): ?>
          0/<?= $maxUser ?>
        <?php else: ?>
        <details>
          <summary><?= count($users) ?>/<?= $maxUser ?></summary>
          <div class="hwid-detail">
            <?php foreach ($users as $u): ?>
            <div class="id-row">
              <span class="id-row-text"><?= htmlspecialchars(ks_display_user_label($u)) ?></span>
              <form method="post" action="admin_bans.php" onsubmit="return confirm('Ban user ini secara global?')">
                <input type="hidden" name="action" value="ban_user">
                <input type="hidden" name="ban_user" value="<?= htmlspecialchars($u) ?>">
                <input type="hidden" name="ban_reason" value="Dari halaman Keys (<?= htmlspecialchars($k['key']) ?>)">
                <button type="submit" class="small red">Ban</button>
              </form>
            </div>
            <?php endforeach; ?>
          </div>
        </details>
        <?php endif; ?>
      </td>
      <td class="wrap-cell"><?= htmlspecialchars($k['note']) ?></td>
      <td>
        <input type="text" readonly value="<?= htmlspecialchars(ks_build_loadstring($k['key'])) ?>" id="<?= $rowId ?>" style="width:140px; font-size:11px; margin-bottom:4px;">
        <button type="button" class="small" onclick="copyField('<?= $rowId ?>')">Copy</button>
      </td>
      <td class="actions">
        <form method="post"><input type="hidden" name="action" value="reset_hwid"><input type="hidden" name="key" value="<?= htmlspecialchars($k['key']) ?>"><button class="small yellow" onclick="return confirm('Reset HWID key ini?')">Reset HWID</button></form>
        <form method="post"><input type="hidden" name="action" value="reset_users"><input type="hidden" name="key" value="<?= htmlspecialchars($k['key']) ?>"><button class="small yellow" onclick="return confirm('Reset daftar user key ini?')">Reset User</button></form>
        <?php if ($k['status'] === 'active'): ?>
          <form method="post"><input type="hidden" name="action" value="revoke"><input type="hidden" name="key" value="<?= htmlspecialchars($k['key']) ?>"><button class="small red">Revoke</button></form>
        <?php else: ?>
          <form method="post"><input type="hidden" name="action" value="activate"><input type="hidden" name="key" value="<?= htmlspecialchars($k['key']) ?>"><button class="small green">Aktifkan</button></form>
        <?php endif; ?>
        <form method="post" style="display:inline-flex; gap:4px; align-items:center; margin-top:4px">
          <input type="hidden" name="action" value="extend">
          <input type="hidden" name="key" value="<?= htmlspecialchars($k['key']) ?>">
          <input type="number" name="extra_days" placeholder="+hari" style="width:70px; padding:4px; margin:0">
          <button class="small">Extend</button>
        </form>
        <form method="post" style="margin-top:4px"><input type="hidden" name="action" value="delete"><input type="hidden" name="key" value="<?= htmlspecialchars($k['key']) ?>"><button class="small red" onclick="return confirm('Hapus permanen key ini?')">Hapus</button></form>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($keys)): ?>
    <tr><td colspan="9" style="text-align:center; color:var(--muted)">Belum ada key.</td></tr>
    <?php endif; ?>
  </table>
  </div>
</div>

<?php ks_admin_footer(); ?>
