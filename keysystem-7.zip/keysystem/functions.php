<?php
/**
 * functions.php
 * Kumpulan fungsi bantu untuk mengelola data key berbasis JSON
 */

require_once __DIR__ . '/config.php';

/**
 * Memastikan folder & file data ada, kalau belum -> buat otomatis
 */
function ks_init_storage() {
    $dir = dirname(KEYS_FILE);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    // Jaga-jaga kalau folder data/ dibuat ulang tanpa file proteksi statis
    // dari paket zip (mis. karena hosting yang tidak menyalin dotfile).
    if (!file_exists($dir . '/.htaccess')) {
        file_put_contents($dir . '/.htaccess', "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n");
    }
    if (!file_exists($dir . '/index.php')) {
        file_put_contents($dir . '/index.php', "<?php\nhttp_response_code(403);\nexit;\n");
    }
    if (!file_exists(KEYS_FILE)) {
        file_put_contents(KEYS_FILE, json_encode(['keys' => []], JSON_PRETTY_PRINT));
    }
    if (!file_exists(LOGS_FILE)) {
        file_put_contents(LOGS_FILE, json_encode(['logs' => []], JSON_PRETTY_PRINT));
    }
}

/**
 * Baca semua data key dari file JSON, dengan file locking agar aman
 * dari race condition saat diakses banyak request bersamaan.
 */
function ks_read_keys() {
    ks_init_storage();
    $fp = fopen(KEYS_FILE, 'r');
    flock($fp, LOCK_SH);
    $content = stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    $data = json_decode($content, true);
    if (!is_array($data) || !isset($data['keys'])) {
        $data = ['keys' => []];
    }
    return $data;
}

/**
 * Tulis data key ke file JSON dengan exclusive lock
 */
function ks_write_keys($data) {
    ks_init_storage();
    $fp = fopen(KEYS_FILE, 'c');
    flock($fp, LOCK_EX);
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($data, JSON_PRETTY_PRINT));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
}

/**
 * Catat log aktivitas (generate, validasi sukses/gagal, reset hwid, dll)
 */
function ks_log($event, $detail = []) {
    ks_init_storage();
    $fp = fopen(LOGS_FILE, 'c+');
    flock($fp, LOCK_EX);
    $content = stream_get_contents($fp);
    $data = json_decode($content, true);
    if (!is_array($data) || !isset($data['logs'])) {
        $data = ['logs' => []];
    }
    $data['logs'][] = array_merge([
        'time'  => date('Y-m-d H:i:s'),
        'event' => $event,
        'ip'    => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    ], $detail);

    // Batasi log maksimal 2000 entri terakhir biar file tidak membengkak
    if (count($data['logs']) > 2000) {
        $data['logs'] = array_slice($data['logs'], -2000);
    }

    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($data, JSON_PRETTY_PRINT));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
}

/**
 * Ambil N entri log terakhir (dari yang paling baru), untuk ditampilkan di
 * panel admin. Opsional filter substring pada nama event (mis. "fail",
 * "success", "ban", "free").
 */
function ks_read_recent_logs($limit = LOG_VIEWER_LIMIT, $eventFilter = '') {
    ks_init_storage();
    if (!file_exists(LOGS_FILE)) return [];
    $data = json_decode(file_get_contents(LOGS_FILE), true);
    $logs = is_array($data) && isset($data['logs']) ? $data['logs'] : [];

    if ($eventFilter !== '') {
        $logs = array_values(array_filter($logs, function ($l) use ($eventFilter) {
            return strpos($l['event'] ?? '', $eventFilter) !== false;
        }));
    }

    $logs = array_slice($logs, -$limit);
    return array_reverse($logs); // terbaru duluan
}

/* ==========================================================================
 * BAN HWID / USER (GLOBAL)
 * Berbeda dari HWID/user yang terikat ke satu key tertentu (max_hwid/
 * max_user), ban di sini berlaku LINTAS semua key dan produk -- termasuk
 * produk free/keyless. Sekali di-ban, HWID/user itu ditolak di mana pun dia
 * mencoba, sampai di-unban lagi.
 * ==========================================================================
 */

function ks_read_bans() {
    if (!file_exists(BANS_FILE)) return ['hwids' => [], 'users' => []];
    $data = json_decode(file_get_contents(BANS_FILE), true);
    if (!is_array($data)) $data = [];
    if (!isset($data['hwids'])) $data['hwids'] = [];
    if (!isset($data['users'])) $data['users'] = [];
    return $data;
}

function ks_write_bans($data) {
    $dir = dirname(BANS_FILE);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    file_put_contents(BANS_FILE, json_encode($data, JSON_PRETTY_PRINT));
}

function ks_ban_hwid($hwid, $reason = '') {
    $hwid = trim($hwid);
    if ($hwid === '') return false;
    $data = ks_read_bans();
    $data['hwids'][$hwid] = ['reason' => $reason, 'banned_at' => time()];
    ks_write_bans($data);
    ks_log('ban_hwid', ['hwid' => $hwid, 'reason' => $reason]);
    return true;
}

function ks_unban_hwid($hwid) {
    $data = ks_read_bans();
    unset($data['hwids'][$hwid]);
    ks_write_bans($data);
    ks_log('unban_hwid', ['hwid' => $hwid]);
    return true;
}

function ks_is_hwid_banned($hwid) {
    if (empty($hwid)) return false;
    $data = ks_read_bans();
    return isset($data['hwids'][$hwid]);
}

function ks_ban_user($userId, $reason = '') {
    $userId = trim($userId);
    if ($userId === '') return false;
    $data = ks_read_bans();
    $data['users'][$userId] = ['reason' => $reason, 'banned_at' => time()];
    ks_write_bans($data);
    ks_log('ban_user', ['userid' => $userId, 'reason' => $reason]);
    return true;
}

function ks_unban_user($userId) {
    $data = ks_read_bans();
    unset($data['users'][$userId]);
    ks_write_bans($data);
    ks_log('unban_user', ['userid' => $userId]);
    return true;
}

function ks_is_user_banned($userId) {
    if (empty($userId)) return false;
    $data = ks_read_bans();
    return isset($data['users'][$userId]);
}

/**
 * Cek gabungan: apakah hwid ATAU userId sedang di-ban. Return pesan error
 * kalau di-ban (untuk langsung dipakai sebagai message penolakan), atau
 * null kalau keduanya bersih. Dipakai di ks_validate_key() (alur berkey)
 * dan free_token.php/get_script.php (alur free/keyless).
 *
 * OPTIMASI: baca bans.json SEKALI saja (sebelumnya ks_is_hwid_banned() dan
 * ks_is_user_banned() masing-masing baca file terpisah -> 2x I/O per
 * pengecekan, padahal fungsi ini dipanggil di jalur tersibuk sistem).
 */
function ks_check_ban($hwid, $userId = null) {
    if (empty($hwid) && empty($userId)) return null;

    $data = ks_read_bans();
    if (!empty($hwid) && isset($data['hwids'][$hwid])) {
        return 'Perangkat ini telah diblokir (banned).';
    }
    if (!empty($userId) && isset($data['users'][$userId])) {
        return 'Akun ini telah diblokir (banned).';
    }
    return null;
}

/* ==========================================================================
 * RESOLVER USERNAME ROBLOX
 * Sistem menyimpan identitas user sebagai UserId numerik (stabil, tidak
 * pernah berubah -- ini yang dipakai untuk semua pencocokan/pengecekan
 * internal). Fungsi-fungsi di bawah HANYA untuk keperluan TAMPILAN di
 * panel admin supaya admin melihat username asli ("Budi123") alih-alih
 * angka ("123456789"), lewat API publik Roblox + cache lokal.
 * ==========================================================================
 */

function ks_read_username_cache() {
    if (!file_exists(USERNAME_CACHE_FILE)) return ['byId' => [], 'byUsername' => []];
    $data = json_decode(file_get_contents(USERNAME_CACHE_FILE), true);
    if (!is_array($data)) $data = [];
    if (!isset($data['byId'])) $data['byId'] = [];
    if (!isset($data['byUsername'])) $data['byUsername'] = [];
    return $data;
}

function ks_write_username_cache($data) {
    $dir = dirname(USERNAME_CACHE_FILE);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    file_put_contents(USERNAME_CACHE_FILE, json_encode($data, JSON_PRETTY_PRINT));
}

function ks_username_cache_remember($userId, $username) {
    $cache = ks_read_username_cache();
    $now = time();
    $cache['byId'][$userId] = ['username' => $username, 'resolved_at' => $now];
    $cache['byUsername'][strtolower($username)] = ['userid' => $userId, 'resolved_at' => $now];
    ks_write_username_cache($cache);
}

/**
 * Resolve UserId Roblox (angka) jadi username asli. Pakai cache lokal dulu
 * (berlaku USERNAME_CACHE_TTL); kalau tidak ada/kedaluwarsa, baru panggil
 * API publik Roblox (dibatasi MAX_USERNAME_LOOKUPS_PER_PAGE panggilan baru
 * per page-load, supaya halaman admin tidak lambat kalau ada banyak user
 * yang belum ter-cache sekaligus). Return null kalau gagal/tidak valid
 * (caller sebaiknya fallback tampilkan UserId mentah).
 */
function ks_resolve_username($userId) {
    static $lookupsUsed = 0;

    $userId = trim((string)$userId);
    if ($userId === '' || !ctype_digit($userId)) return null;

    $cache = ks_read_username_cache();
    $cached = $cache['byId'][$userId] ?? null;
    if ($cached && (time() - $cached['resolved_at']) < USERNAME_CACHE_TTL) {
        return $cached['username'];
    }

    if ($lookupsUsed >= MAX_USERNAME_LOOKUPS_PER_PAGE || !function_exists('curl_init')) {
        // Sudah kehabisan jatah panggilan API baru untuk page-load ini (atau
        // cURL tidak tersedia) -- pakai cache lama walau kedaluwarsa,
        // daripada tidak menampilkan apa-apa.
        return $cached['username'] ?? null;
    }

    $lookupsUsed++;
    $ch = curl_init('https://users.roblox.com/v1/users/' . urlencode($userId));
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => USERNAME_LOOKUP_TIMEOUT,
        CURLOPT_CONNECTTIMEOUT => USERNAME_LOOKUP_TIMEOUT,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($resp === false || $code !== 200) {
        return $cached['username'] ?? null;
    }

    $data = json_decode($resp, true);
    $username = $data['name'] ?? null;
    if (!is_string($username) || $username === '') {
        return $cached['username'] ?? null;
    }

    ks_username_cache_remember($userId, $username);
    return $username;
}

/**
 * Kebalikan dari ks_resolve_username(): cari UserId dari sebuah username.
 * Dipakai supaya admin bisa ban dengan mengetik USERNAME, bukan angka.
 * Return null kalau username tidak ditemukan / API gagal.
 */
function ks_resolve_userid_by_username($username) {
    $username = trim((string)$username);
    if ($username === '') return null;

    $cache = ks_read_username_cache();
    $cached = $cache['byUsername'][strtolower($username)] ?? null;
    if ($cached && (time() - $cached['resolved_at']) < USERNAME_CACHE_TTL) {
        return $cached['userid'];
    }

    if (!function_exists('curl_init')) return $cached['userid'] ?? null;

    $ch = curl_init('https://users.roblox.com/v1/usernames/users');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS     => json_encode(['usernames' => [$username], 'excludeBannedUsers' => false]),
        CURLOPT_TIMEOUT        => USERNAME_LOOKUP_TIMEOUT,
        CURLOPT_CONNECTTIMEOUT => USERNAME_LOOKUP_TIMEOUT,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($resp === false || $code !== 200) return $cached['userid'] ?? null;

    $data = json_decode($resp, true);
    $first = $data['data'][0] ?? null;
    if (!$first || empty($first['id']) || empty($first['name'])) {
        return $cached['userid'] ?? null;
    }

    $userId = (string)$first['id'];
    ks_username_cache_remember($userId, $first['name']);
    return $userId;
}

/**
 * Label tampilan untuk sebuah UserId: "Username (UserId)" kalau berhasil
 * di-resolve, atau UserId mentah kalau gagal/belum sempat di-resolve.
 */
function ks_display_user_label($userId) {
    $username = ks_resolve_username($userId);
    return $username !== null ? "{$username} ({$userId})" : (string)$userId;
}

/**
 * Kumpulkan semua HWID & User ID unik yang pernah tercatat di semua key,
 * untuk mengisi dropdown/datalist di form Ban -- supaya admin tinggal
 * pilih, tidak perlu ketik manual. $withUsernames kalau true, ikut me-
 * resolve username untuk tiap userid (dibatasi MAX_USERNAME_LOOKUPS_PER_PAGE
 * juga, jadi tetap aman dipanggil di halaman yang menampilkan banyak user).
 */
function ks_collect_known_identifiers() {
    $keys = ks_read_keys()['keys'];
    $hwids = [];
    $users = [];
    foreach ($keys as $k) {
        foreach (($k['hwids'] ?? []) as $h) {
            $hwids[$h] = true;
        }
        foreach (($k['users'] ?? []) as $u) {
            $users[$u] = true;
        }
    }
    return ['hwids' => array_keys($hwids), 'users' => array_keys($users)];
}

/**
 * Generate string key acak, format: XXXX-XXXX-XXXX-XXXX
 */
function ks_generate_key_string($segments = 4, $segmentLength = 4) {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // tanpa karakter ambigu (0,O,1,I)
    $parts = [];
    for ($i = 0; $i < $segments; $i++) {
        $part = '';
        for ($j = 0; $j < $segmentLength; $j++) {
            $part .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $parts[] = $part;
    }
    return implode('-', $parts);
}

/**
 * Buat key baru dan simpan ke storage.
 *
 * @param string $product   Nama produk/script pemilik key
 * @param int    $duration  Durasi aktif (detik). 0 = permanen / lifetime
 * @param string $note      Catatan opsional (misal nama pembeli)
 * @param int    $maxHwid   Jumlah HWID/perangkat berbeda yang boleh dipakai (biasanya 1)
 * @param int    $maxUser   Jumlah user/akun berbeda yang boleh memakai key ini (biasanya 1)
 * @return array data key yang baru dibuat
 */
function ks_create_key($product, $duration = null, $note = '', $maxHwid = 1, $maxUser = 1) {
    if ($duration === null) {
        $duration = DEFAULT_DURATION;
    }
    $data = ks_read_keys();

    // Pastikan key unik
    do {
        $keyStr = ks_generate_key_string();
        $exists = false;
        foreach ($data['keys'] as $k) {
            if ($k['key'] === $keyStr) { $exists = true; break; }
        }
    } while ($exists);

    $entry = [
        'key'          => $keyStr,
        'product'      => $product,
        'note'         => $note,
        'created_at'   => time(),
        'expires_at'   => $duration > 0 ? (time() + $duration) : 0, // 0 = lifetime
        'max_hwid'     => (int)$maxHwid,
        'hwids'        => [],       // daftar HWID/perangkat yang sudah terikat ke key ini
        'max_user'     => (int)$maxUser,
        'users'        => [],       // daftar user/akun berbeda yang sudah terikat ke key ini
        'status'       => 'active', // active | revoked | paused
        'total_resets' => 0,
        'last_used_at' => null,
    ];

    $data['keys'][] = $entry;
    ks_write_keys($data);
    ks_log('generate', ['key' => $keyStr, 'product' => $product]);

    return $entry;
}

/**
 * Cari index key berdasarkan string key. Return -1 jika tidak ditemukan.
 */
function ks_find_key_index($data, $keyStr) {
    foreach ($data['keys'] as $i => $k) {
        if (hash_equals($k['key'], $keyStr)) {
            return $i;
        }
    }
    return -1;
}

/**
 * Validasi sebuah key. Ini fungsi inti yang dipanggil script/client.
 *
 * @param string      $keyStr  Key yang dicek
 * @param string      $hwid    Hardware/Device ID pengguna
 * @param string|null $product Nama produk (opsional, untuk verifikasi tambahan)
 * @param string|null $userId  ID user/akun pengguna (opsional, dicek terpisah dari HWID)
 * @return array ['success' => bool, 'message' => string, 'data' => ...]
 */
function ks_validate_key($keyStr, $hwid, $product = null, $userId = null) {
    $data = ks_read_keys();
    $idx = ks_find_key_index($data, $keyStr);

    if ($idx === -1) {
        ks_log('validate_fail', ['key' => $keyStr, 'reason' => 'not_found']);
        return ['success' => false, 'message' => 'Key tidak ditemukan.'];
    }

    $entry = &$data['keys'][$idx];

    // ---- Cek ban global (lintas semua key/produk) SEBELUM apa pun lain,
    // supaya HWID/user yang di-ban tidak sempat menghabiskan slot key. ----
    $banMsg = ks_check_ban($hwid, $userId);
    if ($banMsg !== null) {
        ks_log('validate_fail', ['key' => $keyStr, 'reason' => 'banned', 'hwid' => $hwid, 'user' => $userId]);
        return ['success' => false, 'message' => $banMsg];
    }

    if ($entry['status'] !== 'active') {
        ks_log('validate_fail', ['key' => $keyStr, 'reason' => 'status_' . $entry['status']]);
        return ['success' => false, 'message' => 'Key sudah tidak aktif (' . $entry['status'] . ').'];
    }

    if ($product !== null && $entry['product'] !== $product) {
        ks_log('validate_fail', ['key' => $keyStr, 'reason' => 'wrong_product']);
        return ['success' => false, 'message' => 'Key tidak berlaku untuk produk ini.'];
    }

    if ($entry['expires_at'] !== 0 && time() > $entry['expires_at']) {
        $entry['status'] = 'expired';
        ks_write_keys($data);
        ks_log('validate_fail', ['key' => $keyStr, 'reason' => 'expired']);
        return ['success' => false, 'message' => 'Key sudah kedaluwarsa.'];
    }

    // Kompatibilitas mundur: key lama (dibuat sebelum fitur max_user ada)
    // mungkin belum punya field 'max_user'/'users'.
    if (!isset($entry['max_user'])) $entry['max_user'] = 1;
    if (!isset($entry['users'])) $entry['users'] = [];

    // Cek / kunci HWID (perangkat)
    if (!empty($hwid)) {
        if (in_array($hwid, $entry['hwids'], true)) {
            // HWID sudah terdaftar sebelumnya -> OK
        } elseif (count($entry['hwids']) < $entry['max_hwid']) {
            if (LOCK_HWID_ON_FIRST_USE) {
                $entry['hwids'][] = $hwid;
            }
        } else {
            ks_log('validate_fail', ['key' => $keyStr, 'reason' => 'hwid_limit', 'hwid' => $hwid]);
            return ['success' => false, 'message' => 'Key sudah terikat ke perangkat lain (batas HWID tercapai).'];
        }
    }

    // Cek / kunci User (akun) - independen dari HWID, supaya satu key bisa
    // dibatasi berapa AKUN berbeda yang boleh memakainya, terpisah dari
    // berapa PERANGKAT berbeda yang boleh dipakai.
    if (!empty($userId)) {
        if (in_array($userId, $entry['users'], true)) {
            // User sudah terdaftar sebelumnya -> OK
        } elseif (count($entry['users']) < $entry['max_user']) {
            $entry['users'][] = $userId;
        } else {
            ks_log('validate_fail', ['key' => $keyStr, 'reason' => 'user_limit', 'user' => $userId]);
            return ['success' => false, 'message' => 'Key sudah dipakai oleh user lain (batas user tercapai).'];
        }
    }

    $entry['last_used_at'] = time();
    ks_write_keys($data);
    ks_log('validate_success', ['key' => $keyStr, 'hwid' => $hwid, 'user' => $userId]);

    return [
        'success' => true,
        'message' => 'Key valid.',
        'data' => [
            'product'    => $entry['product'],
            'expires_at' => $entry['expires_at'],
            'lifetime'   => $entry['expires_at'] === 0,
        ],
    ];
}

/**
 * Reset HWID yang terikat pada key (dipakai admin ketika user ganti perangkat)
 */
function ks_reset_hwid($keyStr) {
    $data = ks_read_keys();
    $idx = ks_find_key_index($data, $keyStr);
    if ($idx === -1) return false;

    $data['keys'][$idx]['hwids'] = [];
    $data['keys'][$idx]['total_resets']++;
    ks_write_keys($data);
    ks_log('reset_hwid', ['key' => $keyStr]);
    return true;
}

/**
 * Reset daftar user/akun yang terikat pada key (dipakai admin ketika key
 * dipindahtangankan ke user lain, tanpa perlu mereset binding HWID).
 */
function ks_reset_users($keyStr) {
    $data = ks_read_keys();
    $idx = ks_find_key_index($data, $keyStr);
    if ($idx === -1) return false;

    $data['keys'][$idx]['users'] = [];
    $data['keys'][$idx]['total_resets']++;
    ks_write_keys($data);
    ks_log('reset_users', ['key' => $keyStr]);
    return true;
}

/**
 * Ubah status key: active | revoked | paused
 */
function ks_set_status($keyStr, $status) {
    $data = ks_read_keys();
    $idx = ks_find_key_index($data, $keyStr);
    if ($idx === -1) return false;

    $data['keys'][$idx]['status'] = $status;
    ks_write_keys($data);
    ks_log('set_status', ['key' => $keyStr, 'status' => $status]);
    return true;
}

/**
 * Hapus key permanen
 */
function ks_delete_key($keyStr) {
    $data = ks_read_keys();
    $idx = ks_find_key_index($data, $keyStr);
    if ($idx === -1) return false;

    array_splice($data['keys'], $idx, 1);
    ks_write_keys($data);
    ks_log('delete', ['key' => $keyStr]);
    return true;
}

/* ==========================================================================
 * PROTEKSI SCRIPT
 * Script asli disimpan terenkripsi di server (di luar folder yang bisa
 * diakses langsung lewat URL browser) dan hanya diberikan ke client yang
 * key + HWID-nya sudah tervalidasi. Setiap script yang dikeluarkan juga
 * dibubuhi watermark unik supaya kalau ada yang bocor/redistribusi, sumber
 * kebocorannya bisa dilacak dari key/HWID yang tertanam di dalamnya.
 * ==========================================================================
 */

function ks_scripts_dir() {
    if (!is_dir(SCRIPTS_DIR)) {
        mkdir(SCRIPTS_DIR, 0700, true);
        // Cegah akses langsung via web kalau server pakai Apache
        file_put_contents(SCRIPTS_DIR . '/.htaccess', "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n");
        // Lapisan tambahan kalau .htaccess diabaikan hosting
        file_put_contents(SCRIPTS_DIR . '/index.php', "<?php\nhttp_response_code(403);\nexit;\n");
    }
    return SCRIPTS_DIR;
}

/**
 * Path file terenkripsi untuk sebuah produk. Nama produk di-hash supaya
 * nama file di disk tidak menebak-nebak nama produk aslinya.
 */
function ks_script_path($product) {
    return ks_scripts_dir() . '/' . hash('sha256', strtolower(trim($product))) . '.enc';
}

/**
 * Enkripsi & simpan source code script untuk sebuah produk.
 * Dipanggil dari panel admin saat upload/update script.
 */
function ks_save_script($product, $sourceCode) {
    $iv = random_bytes(16);
    $cipher = openssl_encrypt($sourceCode, 'aes-256-cbc', SCRIPT_ENCRYPT_KEY, OPENSSL_RAW_DATA, $iv);
    $payload = base64_encode($iv . $cipher);
    file_put_contents(ks_script_path($product), $payload);
    ks_update_script_index($product, strlen($sourceCode));
    ks_log('script_upload', ['product' => $product, 'bytes' => strlen($sourceCode)]);
    return true;
}

/**
 * Cek apakah sebuah URL aman untuk di-fetch oleh SERVER (bukan browser
 * admin). Ini mencegah SSRF: admin yang memasukkan URL seperti
 * "http://127.0.0.1/..." atau "http://169.254.169.254/..." (metadata cloud)
 * atau alamat jaringan internal lain tidak akan bisa membuat server
 * mengintip/mengakses sumber daya internalnya sendiri.
 * Hanya http/https ke host publik yang diizinkan.
 */
function ks_is_safe_public_url($url) {
    $parts = parse_url($url);
    if (!$parts || empty($parts['scheme']) || empty($parts['host'])) return false;
    if (!in_array(strtolower($parts['scheme']), ['http', 'https'], true)) return false;

    $host = $parts['host'];
    $ip = filter_var($host, FILTER_VALIDATE_IP) ? $host : gethostbyname($host);

    // gethostbyname() balikin hostname aslinya kalau gagal resolve (bukan IP) -> tolak
    if (!filter_var($ip, FILTER_VALIDATE_IP)) return false;

    // Tolak IP privat/reserved/loopback/link-local (mis. 127.0.0.1, 10.x, 192.168.x,
    // 169.254.x termasuk metadata endpoint cloud, ::1, dst).
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
        return false;
    }

    return true;
}

/**
 * Ambil isi script dari sebuah URL (dipakai fitur "Upload via Link" di
 * panel admin). Dibatasi ukuran (SCRIPT_MAX_BYTES), timeout
 * (SCRIPT_FETCH_TIMEOUT), hanya http/https, redirect dibatasi, dan
 * divalidasi anti-SSRF lewat ks_is_safe_public_url().
 *
 * @return array ['success' => bool, 'message' => string, 'content' => string|null]
 */
function ks_fetch_script_from_url($url) {
    $url = trim($url);
    if ($url === '') {
        return ['success' => false, 'message' => 'URL kosong.', 'content' => null];
    }
    if (!ks_is_safe_public_url($url)) {
        return ['success' => false, 'message' => 'URL tidak diizinkan (harus http/https ke host publik, bukan alamat internal/lokal).', 'content' => null];
    }
    if (!function_exists('curl_init')) {
        return ['success' => false, 'message' => 'Ekstensi cURL tidak tersedia di server ini, tidak bisa mengambil URL.', 'content' => null];
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 3,
        CURLOPT_TIMEOUT        => SCRIPT_FETCH_TIMEOUT,
        CURLOPT_CONNECTTIMEOUT => SCRIPT_FETCH_TIMEOUT,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT      => 'KeySystem-ScriptFetcher/1.0',
        CURLOPT_PROTOCOLS      => defined('CURLPROTO_HTTP') ? (CURLPROTO_HTTP | CURLPROTO_HTTPS) : null,
        CURLOPT_REDIR_PROTOCOLS => defined('CURLPROTO_HTTP') ? (CURLPROTO_HTTP | CURLPROTO_HTTPS) : null,
    ]);
    $body = curl_exec($ch);
    $curlErr = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($body === false) {
        return ['success' => false, 'message' => 'Gagal mengambil URL: ' . $curlErr, 'content' => null];
    }
    if ($httpCode < 200 || $httpCode >= 300) {
        return ['success' => false, 'message' => 'Server tujuan membalas HTTP ' . $httpCode . '.', 'content' => null];
    }
    if (trim($body) === '') {
        return ['success' => false, 'message' => 'File di URL tersebut kosong.', 'content' => null];
    }
    if (strlen($body) > SCRIPT_MAX_BYTES) {
        return ['success' => false, 'message' => 'File terlalu besar (maks ' . round(SCRIPT_MAX_BYTES / 1024 / 1024, 1) . 'MB).', 'content' => null];
    }

    return ['success' => true, 'message' => 'ok', 'content' => $body];
}

/**
 * Simpan index nama produk -> info script (karena nama file di disk di-hash,
 * kita perlu catatan terpisah supaya admin panel bisa menampilkan daftar
 * produk yang sudah punya script beserta ukurannya).
 */
function ks_script_index_path() {
    return dirname(SCRIPTS_DIR) . '/script_index.json';
}

function ks_update_script_index($product, $bytes) {
    $path = ks_script_index_path();
    $data = file_exists($path) ? json_decode(file_get_contents($path), true) : [];
    if (!is_array($data)) $data = [];
    $data[$product] = ['bytes' => $bytes, 'updated_at' => time()];
    file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT));
}

function ks_list_script_products() {
    $path = ks_script_index_path();
    if (!file_exists($path)) return [];
    $data = json_decode(file_get_contents($path), true);
    return is_array($data) ? $data : [];
}

/**
 * Cek apakah sebuah produk sudah punya script tersimpan.
 */
function ks_has_script($product) {
    return file_exists(ks_script_path($product));
}

/* ==========================================================================
 * PRODUK FREE / KEYLESS
 * Beberapa script mungkin ingin dibagikan gratis tanpa perlu key sama
 * sekali, tapi source code aslinya tetap tidak mau di-curl/di-scrape bebas.
 * Produk yang ditandai "free" di sini tetap melalui alur 2-tahap yang sama
 * (loader_free.php -> api/free_token.php -> api/get_script.php), cuma tanpa
 * validasi key. Proteksi lain (rate limit, UA check, token sekali-pakai,
 * watermark) tetap berlaku penuh.
 * ==========================================================================
 */

function ks_read_free_products() {
    if (!file_exists(FREE_PRODUCTS_FILE)) return [];
    $data = json_decode(file_get_contents(FREE_PRODUCTS_FILE), true);
    return is_array($data) ? $data : [];
}

function ks_write_free_products($data) {
    $dir = dirname(FREE_PRODUCTS_FILE);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    file_put_contents(FREE_PRODUCTS_FILE, json_encode($data, JSON_PRETTY_PRINT));
}

/**
 * Nyalakan/matikan status free/keyless untuk sebuah produk. Produk harus
 * sudah punya script ter-upload (lihat ks_has_script) supaya berguna.
 */
function ks_set_product_free($product, $enabled) {
    $data = ks_read_free_products();
    if ($enabled) {
        $data[$product] = ['enabled' => true, 'updated_at' => time()];
    } else {
        unset($data[$product]);
    }
    ks_write_free_products($data);
    ks_log('set_product_free', ['product' => $product, 'enabled' => (bool)$enabled]);
    return true;
}

/**
 * Cek apakah sebuah produk saat ini berstatus free/keyless (bisa diakses
 * tanpa key sama sekali lewat loader_free.php).
 */
function ks_is_product_free($product) {
    $data = ks_read_free_products();
    return !empty($data[$product]['enabled']);
}

/**
 * Ambil & dekripsi source code asli (HANYA dipakai internal server,
 * jangan pernah expose fungsi ini langsung ke endpoint tanpa validasi key).
 */
function ks_load_script_raw($product) {
    $path = ks_script_path($product);
    if (!file_exists($path)) return null;

    $payload = base64_decode(file_get_contents($path));
    $iv = substr($payload, 0, 16);
    $cipher = substr($payload, 16);
    $plain = openssl_decrypt($cipher, 'aes-256-cbc', SCRIPT_ENCRYPT_KEY, OPENSSL_RAW_DATA, $iv);
    return $plain === false ? null : $plain;
}

/**
 * Sisipkan watermark tak-mencolok berisi jejak key/HWID (atau HWID saja
 * untuk script free/keyless) ke dalam script sebelum dikirim ke client.
 * Kalau file ini nanti disebar ulang oleh orang lain, potongan watermark
 * ini bisa dipakai untuk melacak sumbernya.
 *
 * @param string      $sourceCode
 * @param string|null $keyStr Null untuk script free/keyless (tidak ada key)
 * @param string      $hwid
 */
function ks_watermark_script($sourceCode, $keyStr, $hwid) {
    $label = $keyStr !== null && $keyStr !== '' ? substr($keyStr, 0, 4) . '****' : 'FREE';
    $fingerprint = substr(hash('sha256', ($keyStr ?? 'FREE') . '|' . $hwid), 0, 16);
    $comment = "-- licensed to: " . $label . "|" . $fingerprint . "\n";
    return $comment . $sourceCode;
}

/**
 * Rate limiting sederhana berbasis identifier bebas (IP, key, dll),
 * disimpan di JSON. Return true jika request masih diperbolehkan (dan
 * mencatatnya), false jika sudah melewati batas.
 *
 * @param string $identifier Pengenal unik yang di-rate-limit, mis. "ip:1.2.3.4" atau "key:ABCD-..."
 * @param int    $max        Batas maksimal request dalam $window detik
 * @param int    $window     Ukuran jendela waktu (detik)
 */
function ks_rate_limit_check($identifier, $max = SCRIPT_RATE_LIMIT_MAX, $window = SCRIPT_RATE_LIMIT_WINDOW) {
    $fp = fopen(RATELIMIT_FILE, 'c+');
    flock($fp, LOCK_EX);
    $content = stream_get_contents($fp);
    $data = json_decode($content, true);
    if (!is_array($data)) $data = [];

    $now = time();

    // Buang timestamp yang sudah di luar window UNTUK IDENTIFIER INI SAJA.
    // Ini murah -- jumlah entrinya dibatasi oleh $max (biasanya belasan).
    $entries = $data[$identifier] ?? [];
    $entries = array_values(array_filter($entries, function ($t) use ($now, $window) {
        return $t > $now - $window;
    }));

    $allowed = count($entries) < $max;
    if ($allowed) {
        $entries[] = $now;
    }
    $data[$identifier] = $entries;

    // OPTIMASI: jangan bersihkan SELURUH identifier di file ini pada SETIAP
    // request -- fungsi ini dipanggil berkali-kali per satu alur pengambilan
    // script (loader -> validate -> get_script), dan kalau ada ratusan/
    // ribuan identifier berbeda aktif (per-IP, per-key, per-produk), scan
    // penuh tiap request jadi beban CPU/IO yang signifikan di server.
    // Pembersihan menyeluruh cukup dijadwalkan berkala lewat timestamp
    // '_last_cleanup' (lihat CLEANUP_INTERVAL di config).
    $lastCleanup = $data['_last_cleanup'] ?? 0;
    if ($now - $lastCleanup > CLEANUP_INTERVAL) {
        foreach ($data as $id => $times) {
            if ($id === '_last_cleanup') continue;
            if (!is_array($times)) { unset($data[$id]); continue; }
            $times = array_values(array_filter($times, function ($t) use ($now) {
                return $t > $now - 3600;
            }));
            if (empty($times)) {
                unset($data[$id]);
            } else {
                $data[$id] = $times;
            }
        }
        $data['_last_cleanup'] = $now;
    }

    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($data));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);

    return $allowed;
}

/**
 * Base64 URL-safe (dipakai untuk token yang lewat query string URL).
 * Base64 standar bisa mengandung '+', '/', '=' yang berisiko rusak saat
 * dikirim di URL (mis. '+' otomatis dianggap spasi oleh banyak parser),
 * jadi kita pakai varian aman-URL ini untuk token akses script.
 */
function ks_b64url_encode($raw) {
    return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
}
function ks_b64url_decode($encoded) {
    $encoded = strtr($encoded, '-_', '+/');
    $pad = strlen($encoded) % 4;
    if ($pad) {
        $encoded .= str_repeat('=', 4 - $pad);
    }
    return base64_decode($encoded);
}

/**
 * Buat token akses sekali-pakai berumur pendek (default 30 detik) setelah
 * key+HWID divalidasi. Client lalu menukar token ini ke endpoint
 * get_script.php untuk benar-benar mengambil isi script.
 * Ini mempersulit orang yang cuma punya URL endpoint tapi tidak punya key
 * yang sah untuk sekadar "curl" dan menebak-nebak isi script.
 */
function ks_issue_script_token($keyStr, $hwid, $product, $userId = null) {
    $expires = time() + SCRIPT_TOKEN_TTL;
    $payload = ks_b64url_encode(json_encode([
        'key' => $keyStr,
        'hwid' => $hwid,
        'product' => $product,
        'userid' => $userId,
        'exp' => $expires,
        'jti' => bin2hex(random_bytes(8)), // pengenal unik token, untuk cek single-use
    ]));
    $sig = hash_hmac('sha256', $payload, SCRIPT_ENCRYPT_KEY);
    return $payload . '.' . $sig;
}

/**
 * Sama seperti ks_issue_script_token(), tapi khusus untuk produk
 * free/keyless: tidak ada key sama sekali, ditandai flag 'free' => true
 * supaya get_script.php tahu harus melewati validasi key.
 */
function ks_issue_free_script_token($product, $hwid, $userId = null) {
    $expires = time() + SCRIPT_TOKEN_TTL;
    $payload = ks_b64url_encode(json_encode([
        'key' => null,
        'free' => true,
        'hwid' => $hwid,
        'product' => $product,
        'userid' => $userId,
        'exp' => $expires,
        'jti' => bin2hex(random_bytes(8)),
    ]));
    $sig = hash_hmac('sha256', $payload, SCRIPT_ENCRYPT_KEY);
    return $payload . '.' . $sig;
}

/**
 * Verifikasi & pecah token yang dibuat oleh ks_issue_script_token().
 * Return array data jika valid, atau null jika tidak valid/sudah kedaluwarsa.
 * TIDAK memeriksa status single-use di sini — panggil ks_consume_token_once()
 * terpisah setelah ini kalau SCRIPT_TOKEN_SINGLE_USE aktif.
 */
function ks_verify_script_token($token) {
    $parts = explode('.', $token, 2);
    if (count($parts) !== 2) return null;
    [$payload, $sig] = $parts;

    $expectedSig = hash_hmac('sha256', $payload, SCRIPT_ENCRYPT_KEY);
    if (!hash_equals($expectedSig, $sig)) return null;

    $data = json_decode(ks_b64url_decode($payload), true);
    if (!is_array($data) || !isset($data['exp'])) return null;
    if (time() > $data['exp']) return null;

    return $data;
}

/**
 * Tandai sebuah token (via jti) sebagai sudah dipakai. Return true kalau ini
 * pemakaian PERTAMA (boleh lanjut), false kalau token ini sudah pernah
 * dipakai sebelumnya (harus ditolak). Ini mencegah token yang berhasil
 * disadap/dicuri/dibagikan dipakai berkali-kali oleh bot berbeda.
 *
 * @param string|null $jti
 * @param int         $ttlSeconds Berapa lama jejak pemakaian ini disimpan
 *                                sebelum dibersihkan (default 2x TTL token script)
 */
function ks_consume_token_once($jti, $ttlSeconds = null) {
    if (empty($jti)) return true; // token lama tanpa jti (kompatibilitas mundur) - lewati saja
    if ($ttlSeconds === null) $ttlSeconds = SCRIPT_TOKEN_TTL * 2;

    $dir = dirname(USED_TOKENS_FILE);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    if (!file_exists(USED_TOKENS_FILE)) file_put_contents(USED_TOKENS_FILE, json_encode([]));

    $fp = fopen(USED_TOKENS_FILE, 'c+');
    flock($fp, LOCK_EX);
    $content = stream_get_contents($fp);
    $data = json_decode($content, true);
    if (!is_array($data)) $data = [];

    $now = time();

    // OPTIMASI: jangan scan SELURUH isi file di setiap pemanggilan (fungsi
    // ini dipanggil di jalur tersibuk -- tiap fetch script & tiap verifikasi
    // flow ticket). Pembersihan token kedaluwarsa cukup dijadwalkan berkala
    // (lihat CLEANUP_INTERVAL), bukan di setiap request.
    $lastCleanup = $data['_last_cleanup'] ?? 0;
    if ($now - $lastCleanup > CLEANUP_INTERVAL) {
        foreach ($data as $id => $expiresAt) {
            if ($id === '_last_cleanup') continue;
            if (!is_int($expiresAt) || $expiresAt < $now) unset($data[$id]);
        }
        $data['_last_cleanup'] = $now;
    }

    $alreadyUsed = isset($data[$jti]);
    if (!$alreadyUsed) {
        $data[$jti] = $now + $ttlSeconds;
    }

    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($data));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);

    return !$alreadyUsed;
}

/* ==========================================================================
 * FLOW TICKET
 * Tiket berumur sangat pendek (default 15 detik) yang HANYA diterbitkan
 * oleh loader.php / loader_free.php setelah precheck key/produk lolos.
 * validate.php dan free_token.php mewajibkan tiket ini sebelum mau
 * menerbitkan script_token -- menutup celah "curl langsung ke validate.php
 * dengan User-Agent Roblox palsu, skip loader.php sepenuhnya".
 * ==========================================================================
 */

/**
 * Terbitkan flow ticket baru, diikat ke IP yang memintanya saat itu DAN ke
 * $context (biasanya key string untuk alur berkey, atau "free:<produk>"
 * untuk alur free/keyless). Binding ke context ini penting: tanpanya,
 * tiket yang diterbitkan untuk key A (dari IP yang sama) bisa "dipinjam"
 * untuk memvalidasi key B curian dari IP yang sama juga -- karena
 * sebelumnya verifikasi cuma cek IP, bukan context spesifiknya.
 */
function ks_issue_flow_ticket($ip, $context) {
    $expires = time() + FLOW_TICKET_TTL;
    $payload = ks_b64url_encode(json_encode([
        'ip'   => $ip,
        'ctx'  => hash('sha256', (string)$context),
        'exp'  => $expires,
        'jti'  => bin2hex(random_bytes(8)),
    ]));
    $sig = hash_hmac('sha256', $payload, SCRIPT_ENCRYPT_KEY);
    return $payload . '.' . $sig;
}

/**
 * Verifikasi flow ticket: tanda tangan valid, belum kedaluwarsa, IP cocok
 * (kalau REQUIRE_SAME_IP_FOR_TICKET aktif), context cocok (harus persis
 * sama dengan yang dipakai saat tiket diterbitkan -- lihat
 * ks_issue_flow_ticket), dan belum pernah dipakai sebelumnya (sekali
 * pakai). Return true/false.
 */
function ks_verify_flow_ticket($ticket, $currentIp, $expectedContext) {
    if (empty($ticket)) return false;

    $parts = explode('.', $ticket, 2);
    if (count($parts) !== 2) return false;
    [$payload, $sig] = $parts;

    $expectedSig = hash_hmac('sha256', $payload, SCRIPT_ENCRYPT_KEY);
    if (!hash_equals($expectedSig, $sig)) return false;

    $data = json_decode(ks_b64url_decode($payload), true);
    if (!is_array($data) || !isset($data['exp'])) return false;
    if (time() > $data['exp']) return false;

    if (REQUIRE_SAME_IP_FOR_TICKET && ($data['ip'] ?? null) !== $currentIp) return false;

    $expectedCtxHash = hash('sha256', (string)$expectedContext);
    if (!hash_equals($expectedCtxHash, $data['ctx'] ?? '')) return false;

    // Sekali pakai: dipakai satu kali untuk satu permintaan script_token
    if (!ks_consume_token_once($data['jti'] ?? null, FLOW_TICKET_TTL * 2)) return false;

    return true;
}

/**
 * Cek apakah request saat ini datang lewat HTTPS. Mendukung setup di
 * belakang reverse proxy/load balancer yang meneruskan skema asli lewat
 * header X-Forwarded-Proto.
 */
function ks_is_https() {
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;
    if (($_SERVER['SERVER_PORT'] ?? null) == 443) return true;
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') return true;
    return false;
}

/**
 * Heuristik ringan: apakah User-Agent request ini terlihat seperti berasal
 * dari Roblox (game:HttpGet / HttpService), bukan tool umum seperti curl,
 * wget, python-requests, PostmanRuntime, dsb. BUKAN proteksi absolut (UA
 * bisa dipalsukan), tapi cukup untuk menyaring mayoritas bot/stealer
 * generik yang asal hit endpoint tanpa menyamar.
 */
function ks_looks_like_roblox_request() {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if ($ua === '') return false; // Roblox selalu mengirim UA; UA kosong = mencurigakan

    $blockedPatterns = ['curl', 'wget', 'python-requests', 'postmanruntime', 'insomnia', 'go-http-client', 'okhttp', 'axios', 'node-fetch', 'java/', 'libwww-perl', 'scrapy'];
    $uaLower = strtolower($ua);
    foreach ($blockedPatterns as $pattern) {
        if (strpos($uaLower, $pattern) !== false) return false;
    }

    return strpos($uaLower, 'roblox') !== false;
}

/**
 * Escape untuk disisipkan sebagai literal string Lua (cegah nama produk/key
 * yang mengandung tanda kutip merusak atau menyuntik kode ke dalam stub).
 * Dipakai bersama oleh loader.php dan loader_free.php.
 */
function ks_lua_escape($str) {
    return str_replace(
        ['\\', '"', "\n", "\r"],
        ['\\\\', '\\"', '\\n', '\\r'],
        (string)$str
    );
}

/**
 * Minify sangat sederhana: buang komentar baris (--...) dan blok
 * (--[[ ... ]]) serta baris kosong berlebih. Ini BUKAN obfuscator berat,
 * hanya lapisan tambahan supaya isi script tidak "polos" saat diintip
 * sekilas dari traffic/log.
 */
function ks_minify_lua($code) {
    // Hapus komentar blok --[[ ... ]]
    $code = preg_replace('/--\[\[.*?\]\]/s', '', $code);
    // Hapus komentar baris -- ... (yang bukan bagian dari string literal sederhana)
    $lines = explode("\n", $code);
    $out = [];
    foreach ($lines as $line) {
        // Heuristik ringan: kalau baris tidak mengandung tanda kutip sebelum '--', aman dipotong
        $pos = strpos($line, '--');
        if ($pos !== false && strpos(substr($line, 0, $pos), '"') === false && strpos(substr($line, 0, $pos), "'") === false) {
            $line = substr($line, 0, $pos);
        }
        $trimmed = trim($line);
        if ($trimmed !== '') {
            $out[] = $trimmed;
        }
    }
    return implode("\n", $out);
}

/**
 * Deteksi/susun base URL publik untuk generate loadstring otomatis.
 */
function ks_base_url() {
    if (BASE_URL !== '') {
        return rtrim(BASE_URL, '/');
    }
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'domainmu.com';
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/keysystem/admin.php')), '/');
    return $scheme . '://' . $host . $dir;
}

/**
 * Buat string loadstring siap-pakai untuk sebuah key. Ini yang dipakai
 * user tinggal copy-paste ke executor mereka.
 * Bentuknya SELALU memanggil loader.php (stage-1), bukan langsung ke
 * get_script.php, supaya alur 2-tahap tetap terjaga.
 */
function ks_build_loadstring($keyStr) {
    $url = ks_base_url() . '/loader.php?key=' . urlencode($keyStr);
    return 'loadstring(game:HttpGet("' . $url . '"))()';
}

/**
 * Sama seperti ks_build_loadstring(), tapi untuk produk free/keyless:
 * memanggil loader_free.php dengan parameter product, bukan key.
 */
function ks_build_free_loadstring($product) {
    $url = ks_base_url() . '/loader_free.php?product=' . urlencode($product);
    return 'loadstring(game:HttpGet("' . $url . '"))()';
}

/**
 * Perpanjang masa aktif key
 */
function ks_extend_key($keyStr, $extraSeconds) {
    $data = ks_read_keys();
    $idx = ks_find_key_index($data, $keyStr);
    if ($idx === -1) return false;

    $entry = &$data['keys'][$idx];
    if ($entry['expires_at'] === 0) {
        // sudah lifetime, tidak perlu diperpanjang
        return true;
    }
    $base = max($entry['expires_at'], time());
    $entry['expires_at'] = $base + $extraSeconds;
    if ($entry['status'] === 'expired') {
        $entry['status'] = 'active';
    }
    ks_write_keys($data);
    ks_log('extend', ['key' => $keyStr, 'extra_seconds' => $extraSeconds]);
    return true;
}
