<?php
/**
 * api/validate.php
 *
 * Endpoint publik untuk validasi key.
 * Dipanggil oleh script/aplikasi client saat mengecek apakah key sah.
 *
 * Contoh pemanggilan (GET):
 *   /api/validate.php?key=XXXX-XXXX-XXXX-XXXX&hwid=abc123&userid=456&product=MyScript
 *
 * Contoh pemanggilan (POST JSON):
 *   { "key": "XXXX-XXXX-XXXX-XXXX", "hwid": "abc123", "userid": "456", "product": "MyScript" }
 *
 * Parameter "userid" opsional dan independen dari "hwid": hwid membatasi
 * jumlah PERANGKAT berbeda yang boleh memakai key (max_hwid), sedangkan
 * userid membatasi jumlah AKUN/USER berbeda yang boleh memakainya (max_user).
 */

require_once __DIR__ . '/../functions.php';

$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

// ---- Deteksi User-Agent yang jelas bukan Roblox (curl/bot/stealer generik).
// Ini penting di endpoint ini karena di sinilah slot HWID/User benar-benar
// terisi -- kalau dibiarkan, bot bisa "menghabiskan" slot key orang lain
// pakai HWID palsu tanpa pernah jadi pengguna sah. Matikan lewat config
// kalau kamu perlu tes manual dari luar Roblox.
if (REQUIRE_ROBLOX_USER_AGENT && !ks_looks_like_roblox_request()) {
    ks_log('validate_fail', ['reason' => 'blocked_user_agent', 'ip' => $ip, 'ua' => $_SERVER['HTTP_USER_AGENT'] ?? '']);
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Request ditolak.']);
    exit;
}

// ---- RATE LIMIT berbasis IP, mencegah brute-force menebak key ----
if (!ks_rate_limit_check('validate:' . $ip)) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Terlalu banyak permintaan. Coba lagi sebentar.']);
    exit;
}

// Ambil parameter, mendukung GET maupun POST (JSON body atau form-data)
$input = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $json = json_decode($raw, true);
    if (is_array($json)) {
        $input = $json;
    } else {
        $input = $_POST;
    }
} else {
    $input = $_GET;
}

$key     = trim($input['key'] ?? '');
$hwid    = trim($input['hwid'] ?? '');
$userId  = isset($input['userid']) ? trim($input['userid']) : null;
$product = isset($input['product']) ? trim($input['product']) : null;
$ticket  = trim($input['ticket'] ?? '');

if ($key === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Parameter "key" wajib diisi.']);
    exit;
}

$result = ks_validate_key($key, $hwid, $product, $userId);

// Kalau key valid dan produk ini punya script terdaftar, sertakan token
// sekali-pakai (berumur pendek) supaya client bisa menukarnya di
// get_script.php. Client TIDAK pernah menerima script langsung dari sini.
//
// WAJIB flow ticket yang sah (hanya diterbitkan oleh loader.php) di sini --
// ini menutup celah orang yang curl LANGSUNG ke endpoint ini (skip
// loader.php sepenuhnya) dengan User-Agent Roblox palsu untuk mendapat
// script_token. Kalau tiket tidak ada/tidak valid, key TETAP dianggap valid
// (field lain di response tetap terisi normal), tapi script_token TIDAK
// diterbitkan -- jadi permintaan berikutnya ke get_script.php pasti gagal.
if ($result['success']) {
    $targetProduct = $product ?? $result['data']['product'];
    if (ks_has_script($targetProduct)) {
        $ticketOk = !REQUIRE_FLOW_TICKET || ks_verify_flow_ticket($ticket, $ip, $key);
        if ($ticketOk) {
            $result['data']['script_token'] = ks_issue_script_token($key, $hwid, $targetProduct, $userId);
            $result['data']['script_endpoint'] = 'get_script.php';
            $result['data']['token_ttl'] = SCRIPT_TOKEN_TTL;
        } else {
            ks_log('validate_fail', ['reason' => 'missing_or_invalid_ticket', 'key' => $key, 'ip' => $ip]);
        }
    }
}

http_response_code($result['success'] ? 200 : 403);
echo json_encode($result, JSON_PRETTY_PRINT);
