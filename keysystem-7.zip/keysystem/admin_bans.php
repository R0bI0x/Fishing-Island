<?php
/**
 * admin_bans.php
 * Halaman ban/unban HWID & User secara GLOBAL (lintas semua key/produk,
 * termasuk produk Free/Keyless).
 *
 * Form ban tidak lagi wajib diketik manual: HWID/User yang sudah pernah
 * tercatat di key manapun otomatis muncul sebagai saran (datalist), tinggal
 * pilih. Untuk User, bisa juga langsung ketik USERNAME Roblox (bukan cuma
 * angka UserId) -- server yang meng-resolve ke UserId lewat API Roblox.
 */
require_once __DIR__ . '/admin_auth.php';
ks_admin_require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $banError = null;

    if ($action === 'ban_hwid') {
        $hwid = trim($_POST['ban_hwid'] ?? '');
        $reason = trim($_POST['ban_reason'] ?? '');
        if ($hwid === '') {
            $banError = 'HWID wajib diisi/dipilih.';
        } else {
            ks_ban_hwid($hwid, $reason);
        }
    } elseif ($action === 'unban_hwid') {
        $hwid = trim($_POST['hwid'] ?? '');
        if ($hwid !== '') ks_unban_hwid($hwid);
    } elseif ($action === 'ban_user') {
        $input  = trim($_POST['ban_user'] ?? '');
        $reason = trim($_POST['ban_reason'] ?? '');
        if ($input === '') {
            $banError = 'Username atau User ID wajib diisi/dipilih.';
        } else {
            // Terima angka (UserId langsung) ATAU teks (username, di-resolve dulu)
            $userId = ctype_digit($input) ? $input : ks_resolve_userid_by_username($input);
            if ($userId === null) {
                $banError = 'Username "' . $input . '" tidak ditemukan (gagal resolve ke UserId Roblox).';
            } else {
                ks_ban_user($userId, $reason);
            }
        }
    } elseif ($action === 'unban_user') {
        $userId = trim($_POST['userid'] ?? '');
        if ($userId !== '') ks_unban_user($userId);
    }

    if ($banError !== null) {
        $_SESSION['ks_ban_error'] = $banError;
    }

    header('Location: admin_bans.php');
    exit;
}

$bans = ks_read_bans();
$known = ks_collect_known_identifiers();

$banError = null;
if (!empty($_SESSION['ks_ban_error'])) {
    $banError = $_SESSION['ks_ban_error'];
    unset($_SESSION['ks_ban_error']);
}

ks_admin_header('bans', 'Bans');
?>

<div class="card">
  <h3 style="margin-top:0">Ban HWID / User (Global)</h3>
  <p class="sub" style="margin-top:-8px">
    Berbeda dari batas per-key (Maks. HWID/User di halaman Keys), ban di sini berlaku LINTAS semua key
    dan produk (termasuk produk Free/Keyless). Sekali di-ban, perangkat/akun itu ditolak di mana pun ia
    mencoba — dan dicek paling awal, sebelum sempat menghabiskan slot HWID/User key mana pun.
    Cara tercepat: buka halaman <a href="admin_keys.php">Keys</a>, lihat detail HWID/User tiap key, lalu
    klik tombol Ban di sana langsung. Form di bawah ini alternatif kalau perlu ban manual.
  </p>

  <?php if ($banError): ?>
  <div class="error"><?= htmlspecialchars($banError) ?></div>
  <?php endif; ?>

  <div class="grid">
    <form method="post">
      <input type="hidden" name="action" value="ban_hwid">
      <label>Ban HWID (pilih dari saran, atau ketik manual)</label>
      <input type="text" name="ban_hwid" list="knownHwidsList" placeholder="Pilih atau ketik HWID">
      <datalist id="knownHwidsList">
        <?php foreach ($known['hwids'] as $h): ?>
        <option value="<?= htmlspecialchars($h) ?>">
        <?php endforeach; ?>
      </datalist>
      <label>Alasan (opsional)</label>
      <input type="text" name="ban_reason" placeholder="mis. cheating / redistribusi script">
      <button type="submit" class="red">Ban HWID Ini</button>
    </form>
    <form method="post">
      <input type="hidden" name="action" value="ban_user">
      <label>Ban User (pilih dari saran, atau ketik username Roblox)</label>
      <input type="text" name="ban_user" list="knownUsersList" placeholder="Pilih, atau ketik username Roblox">
      <datalist id="knownUsersList">
        <?php foreach ($known['users'] as $u): ?>
        <?php $label = ks_display_user_label($u); ?>
        <option value="<?= htmlspecialchars($u) ?>" label="<?= htmlspecialchars($label) ?>"><?= htmlspecialchars($label) ?></option>
        <?php endforeach; ?>
      </datalist>
      <p class="sub" style="margin-top:-4px;">Bisa pilih dari saran (otomatis terisi UserId-nya), atau ketik username Roblox manapun — server akan mencari UserId-nya sendiri.</p>
      <label>Alasan (opsional)</label>
      <input type="text" name="ban_reason" placeholder="mis. cheating / redistribusi script">
      <button type="submit" class="red">Ban User Ini</button>
    </form>
  </div>
</div>

<div class="card">
  <h3 style="margin-top:0">Daftar yang Di-ban (<?= count($bans['hwids']) + count($bans['users']) ?>)</h3>
  <div class="table-responsive">
  <table>
    <tr><th>Tipe</th><th>ID</th><th>Alasan</th><th>Waktu Ban</th><th>Aksi</th></tr>
    <?php foreach ($bans['hwids'] as $hwid => $info): ?>
    <tr>
      <td><span class="badge revoked">HWID</span></td>
      <td class="key-str"><?= htmlspecialchars($hwid) ?></td>
      <td class="wrap-cell"><?= htmlspecialchars($info['reason'] ?? '') ?></td>
      <td><?= ks_fmt_date($info['banned_at'] ?? null) ?></td>
      <td class="actions">
        <form method="post"><input type="hidden" name="action" value="unban_hwid"><input type="hidden" name="hwid" value="<?= htmlspecialchars($hwid) ?>"><button class="small green">Unban</button></form>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php foreach ($bans['users'] as $userId => $info): ?>
    <tr>
      <td><span class="badge revoked">USER</span></td>
      <td class="key-str"><?= htmlspecialchars(ks_display_user_label($userId)) ?></td>
      <td class="wrap-cell"><?= htmlspecialchars($info['reason'] ?? '') ?></td>
      <td><?= ks_fmt_date($info['banned_at'] ?? null) ?></td>
      <td class="actions">
        <form method="post"><input type="hidden" name="action" value="unban_user"><input type="hidden" name="userid" value="<?= htmlspecialchars($userId) ?>"><button class="small green">Unban</button></form>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($bans['hwids']) && empty($bans['users'])): ?>
    <tr><td colspan="5" style="text-align:center; color:var(--muted)">Belum ada yang di-ban.</td></tr>
    <?php endif; ?>
  </table>
  </div>
</div>

<?php ks_admin_footer(); ?>
