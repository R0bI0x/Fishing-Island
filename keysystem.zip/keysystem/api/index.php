<?php
// Fallback kalau .htaccess (Options -Indexes) diabaikan oleh hosting:
// daripada menampilkan directory listing isi folder api/, balas 403 kosong.
http_response_code(403);
exit;
