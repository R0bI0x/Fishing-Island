<?php
/**
 * api/free_token.php
 *
 * Versi "validate.php" khusus untuk produk FREE/KEYLESS: tidak perlu key
 * sama sekali, cukup nama produk. Kalau produk itu memang ditandai free
 * oleh admin dan sudah punya script ter-upload, endpoint ini menerbitkan
 * script_token sekali-pakai (sama seperti alur berbayar) untuk ditukar ke
 * api/get_script.php.
 *
 * Dipanggil dari stub loader_free.php, bukan langsung oleh pengguna.
 *
 * Contoh (GET):
 *   /api/free_token.php?product=MyFreeScript&hwid=abc123&userid=456
 */

require_once __DIR__ . '/../functions.php';

$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

// ---- Wajib HTTPS (kalau diaktifkan) ----
if (REQUIRE_HTTPS && !ks_is_https()) {
    ks_log('free_token_fail', ['reason' => 'not_https', 'ip' => $ip]);
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Akses wajib lewat HTTPS.']);
    exit;
}

// ---- Deteksi User-Agent yang jelas bukan Roblox ----
if (REQUIRE_ROBLOX_USER_AGENT && !ks_looks_like_roblox_request()) {
    ks_log('free_token_fail', ['reason' => 'blocked_user_agent', 'ip' => $ip, 'ua' => $_SERVER['HTTP_USER_AGENT'] ?? '']);
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Request ditolak.']);
    exit;
}

// ---- RATE LIMIT per-IP ----
if (!ks_rate_limit_check('freetoken:' . $ip)) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Terlalu banyak permintaan. Coba lagi sebentar.']);
    exit;
}

$input = $_SERVER['REQUEST_METHOD'] === 'POST'
    ? (is_array($j = json_decode(file_get_contents('php://input'), true)) ? $j : $_POST)
    : $_GET;

$product = trim($input['product'] ?? '');
$hwid    = trim($input['hwid'] ?? '');
$userId  = isset($input['userid']) ? trim($input['userid']) : null;
$ticket  = trim($input['ticket'] ?? '');

if ($product === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Parameter "product" wajib diisi.']);
    exit;
}

// ---- WAJIB flow ticket yang sah (hanya diterbitkan oleh loader_free.php).
// Endpoint ini SATU-SATUNYA tujuannya menerbitkan script_token, jadi tanpa
// tiket yang valid, permintaan ditolak MUTLAK -- ini menutup celah curl
// langsung ke endpoint ini (skip loader_free.php) dengan User-Agent Roblox
// palsu untuk mendapat script_token produk free tanpa pernah lewat stub. ----
if (REQUIRE_FLOW_TICKET && !ks_verify_flow_ticket($ticket, $ip)) {
    ks_log('free_token_fail', ['reason' => 'missing_or_invalid_ticket', 'product' => $product, 'ip' => $ip]);
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Akses tidak sah. Jalankan ulang loadstring.']);
    exit;
}

// ---- Cek ban global (HWID/user yang di-ban admin tidak bisa akses produk free) ----
$banMsg = ks_check_ban($hwid, $userId);
if ($banMsg !== null) {
    ks_log('free_token_fail', ['reason' => 'banned', 'product' => $product, 'hwid' => $hwid, 'userid' => $userId, 'ip' => $ip]);
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => $banMsg]);
    exit;
}

// ---- RATE LIMIT tambahan per-PRODUK (produk free bisa diakses siapa saja) ----
if (!ks_rate_limit_check('freetokenproduct:' . $product, FREE_RATE_LIMIT_MAX, FREE_RATE_LIMIT_WINDOW)) {
    ks_log('free_token_fail', ['reason' => 'rate_limited_product', 'product' => $product, 'ip' => $ip]);
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Terlalu banyak permintaan untuk produk ini. Coba lagi sebentar.']);
    exit;
}

if (!ks_is_product_free($product)) {
    ks_log('free_token_fail', ['reason' => 'not_free_product', 'product' => $product, 'ip' => $ip]);
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Produk ini tidak tersedia secara gratis.']);
    exit;
}

if (!ks_has_script($product)) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Script untuk produk ini belum tersedia.']);
    exit;
}

$token = ks_issue_free_script_token($product, $hwid, $userId);
ks_log('free_token_issued', ['product' => $product, 'ip' => $ip]);

echo json_encode([
    'success' => true,
    'data' => [
        'product'         => $product,
        'script_token'    => $token,
        'script_endpoint' => 'get_script.php',
        'token_ttl'       => SCRIPT_TOKEN_TTL,
    ],
], JSON_PRETTY_PRINT);
