<?php
/**
 * api/get_script.php
 *
 * Endpoint STAGE-2: mengeluarkan isi script asli, HANYA bisa diakses
 * menggunakan token sekali-pakai berumur pendek yang diterbitkan oleh
 * loader.php (stage-1) SETELAH hwid asli client diketahui.
 *
 * Endpoint ini SENGAJA tidak menerima key secara langsung tanpa token yang
 * sudah lolos verifikasi hwid, supaya orang yang cuma menemukan URL endpoint
 * tanpa melalui loader.php tidak bisa asal curl untuk mengambil script.
 *
 * Mode respons:
 *   - Default: JSON (dipakai kalau endpoint ini dipanggil manual/dari kode PHP lain)
 *   - Kalau dipanggil dengan &raw=1 : balas PLAIN TEXT source Lua langsung,
 *     ini mode yang dipakai oleh stub loader.php di dalam loadstring().
 */

require_once __DIR__ . '/../functions.php';

$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) $input = $_POST;

$token   = trim($input['token'] ?? ($_GET['token'] ?? ''));
$rawMode = isset($_GET['raw']) && $_GET['raw'] == '1';

function ks_fail_raw_or_json($rawMode, $message, $code) {
    http_response_code($code);
    if ($rawMode) {
        header('Content-Type: text/plain; charset=utf-8');
        // Dikembalikan sebagai kode Lua yang valid supaya loadstring() di
        // client gagal dengan pesan jelas, bukan error parsing membingungkan.
        echo 'error(' . var_export($message, true) . ')';
    } else {
        echo json_encode(['success' => false, 'message' => $message]);
    }
    exit;
}

// ---- Wajib HTTPS (cegah key/token disadap di jaringan) ----
if (REQUIRE_HTTPS && !ks_is_https()) {
    ks_log('script_fetch_fail', ['reason' => 'not_https', 'ip' => $ip]);
    ks_fail_raw_or_json($rawMode, 'Akses wajib lewat HTTPS.', 403);
}

// ---- Deteksi User-Agent yang jelas bukan Roblox (curl/bot/stealer generik) ----
if (REQUIRE_ROBLOX_USER_AGENT && !ks_looks_like_roblox_request()) {
    ks_log('script_fetch_fail', ['reason' => 'blocked_user_agent', 'ip' => $ip, 'ua' => $_SERVER['HTTP_USER_AGENT'] ?? '']);
    ks_fail_raw_or_json($rawMode, 'Request ditolak.', 403);
}

// ---- RATE LIMIT berbasis IP, biar tidak gampang di-brute-force / discrape ----
if (!ks_rate_limit_check('script:' . $ip)) {
    ks_log('script_fetch_fail', ['reason' => 'rate_limited_ip', 'ip' => $ip]);
    ks_fail_raw_or_json($rawMode, 'Terlalu banyak permintaan. Coba lagi sebentar.', 429);
}

if ($token === '') {
    ks_fail_raw_or_json($rawMode, 'Parameter token wajib diisi.', 400);
}

$tokenData = ks_verify_script_token($token);
if ($tokenData === null) {
    ks_log('script_fetch_fail', ['reason' => 'invalid_or_expired_token', 'ip' => $ip]);
    ks_fail_raw_or_json($rawMode, 'Token tidak valid atau kedaluwarsa. Jalankan ulang loadstring.', 403);
}

$isFree = !empty($tokenData['free']);

// ---- RATE LIMIT TAMBAHAN: per-KEY untuk script berbayar, atau per-PRODUK
// untuk script free/keyless (karena tidak ada key yang bisa dijadikan
// identifier) -- menahan botnet lintas-IP yang menyasar 1 key/produk sama.
if ($isFree) {
    if (!ks_rate_limit_check('freeproduct:' . $tokenData['product'], FREE_RATE_LIMIT_MAX, FREE_RATE_LIMIT_WINDOW)) {
        ks_log('script_fetch_fail', ['reason' => 'rate_limited_free_product', 'product' => $tokenData['product'], 'ip' => $ip]);
        ks_fail_raw_or_json($rawMode, 'Terlalu banyak permintaan untuk produk ini. Coba lagi sebentar.', 429);
    }
} else {
    if (!ks_rate_limit_check('scriptkey:' . $tokenData['key'], KEY_RATE_LIMIT_MAX, KEY_RATE_LIMIT_WINDOW)) {
        ks_log('script_fetch_fail', ['reason' => 'rate_limited_key', 'key' => $tokenData['key'], 'ip' => $ip]);
        ks_fail_raw_or_json($rawMode, 'Terlalu banyak permintaan untuk key ini. Coba lagi sebentar.', 429);
    }
}

// ---- SINGLE-USE TOKEN: tolak kalau token ini sudah pernah dipakai sebelumnya ----
if (SCRIPT_TOKEN_SINGLE_USE) {
    $firstUse = ks_consume_token_once($tokenData['jti'] ?? null);
    if (!$firstUse) {
        ks_log('script_fetch_fail', ['reason' => 'token_reused', 'key' => $tokenData['key'] ?? null, 'ip' => $ip]);
        ks_fail_raw_or_json($rawMode, 'Token sudah pernah digunakan. Jalankan ulang loadstring.', 403);
    }
}

if ($isFree) {
    // Cek ban ulang (jaga-jaga kalau admin baru saja ban setelah token terbit)
    $banMsg = ks_check_ban($tokenData['hwid'], $tokenData['userid'] ?? null);
    if ($banMsg !== null) {
        ks_log('script_fetch_fail', ['reason' => 'banned', 'product' => $tokenData['product'], 'ip' => $ip]);
        ks_fail_raw_or_json($rawMode, $banMsg, 403);
    }
    // Validasi ulang: produk masih ditandai free & masih punya script
    // (jaga-jaga kalau admin mencabut status free setelah token terbit).
    if (!ks_is_product_free($tokenData['product']) || !ks_has_script($tokenData['product'])) {
        ks_log('script_fetch_fail', ['reason' => 'product_no_longer_free', 'product' => $tokenData['product']]);
        ks_fail_raw_or_json($rawMode, 'Produk ini tidak lagi tersedia secara gratis.', 403);
    }
} else {
    // Validasi ULANG key + hwid saat ini juga (jaga-jaga kalau key sudah
    // direvoke/expired setelah token diterbitkan, atau HWID berubah).
    $check = ks_validate_key($tokenData['key'], $tokenData['hwid'], $tokenData['product'], $tokenData['userid'] ?? null);
    if (!$check['success']) {
        ks_log('script_fetch_fail', ['reason' => 'key_no_longer_valid', 'key' => $tokenData['key']]);
        ks_fail_raw_or_json($rawMode, 'Key tidak lagi valid: ' . $check['message'], 403);
    }
}

$source = ks_load_script_raw($tokenData['product']);
if ($source === null) {
    ks_fail_raw_or_json($rawMode, 'Script untuk produk ini belum tersedia.', 404);
}

if (MINIFY_ON_SERVE) {
    $source = ks_minify_lua($source);
}

// Sisipkan watermark unik (jejak key+hwid, atau hwid saja untuk free) ke
// source sebelum dikirim.
$watermarked = ks_watermark_script($source, $tokenData['key'] ?? null, $tokenData['hwid']);

ks_log('script_fetch_success', ['key' => $tokenData['key'] ?? null, 'product' => $tokenData['product'], 'free' => $isFree, 'ip' => $ip]);

if ($rawMode) {
    header('Content-Type: text/plain; charset=utf-8');
    echo $watermarked;
    exit;
}

echo json_encode([
    'success' => true,
    'product' => $tokenData['product'],
    'source'  => $watermarked,
], JSON_PRETTY_PRINT);
