<?php
/**
 * api/generate.php
 *
 * Endpoint khusus ADMIN untuk membuat key baru lewat API.
 * Wajib menyertakan admin_password yang sama dengan config.php.
 *
 * Contoh (POST JSON):
 * {
 *   "admin_password": "kemplongxd",
 *   "product": "MyScript",
 *   "duration_days": 30,
 *   "note": "pembeli: budi",
 *   "max_hwid": 1,
 *   "max_user": 1
 * }
 *
 * "max_hwid" = jumlah PERANGKAT berbeda yang boleh memakai key ini.
 * "max_user" = jumlah AKUN/USER berbeda yang boleh memakai key ini (independen dari max_hwid).
 * Kirim "duration_days": 0 untuk key permanent/lifetime.
 */

require_once __DIR__ . '/../functions.php';

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = $_POST;
}

$password = $input['admin_password'] ?? '';
if (!hash_equals(ADMIN_PASSWORD, (string)$password)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Password admin salah.']);
    exit;
}

$product      = trim($input['product'] ?? 'default');
$durationDays = isset($input['duration_days']) ? (float)$input['duration_days'] : null;
$duration     = $durationDays !== null ? (int)($durationDays * 86400) : null; // null -> pakai default config
$note         = trim($input['note'] ?? '');
$maxHwid      = isset($input['max_hwid']) ? (int)$input['max_hwid'] : 1;
$maxUser      = isset($input['max_user']) ? (int)$input['max_user'] : 1;

$entry = ks_create_key($product, $duration, $note, $maxHwid, $maxUser);
$entry['loadstring'] = ks_build_loadstring($entry['key']);

echo json_encode(['success' => true, 'data' => $entry], JSON_PRETTY_PRINT);
