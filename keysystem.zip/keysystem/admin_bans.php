<?php
/**
 * admin_bans.php
 * Halaman ban/unban HWID & User secara GLOBAL (lintas semua key/produk,
 * termasuk produk Free/Keyless).
 */
require_once __DIR__ . '/admin_auth.php';
ks_admin_require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'ban_hwid') {
        $hwid = trim($_POST['ban_hwid'] ?? '');
        $reason = trim($_POST['ban_reason'] ?? '');
        if ($hwid !== '') ks_ban_hwid($hwid, $reason);
    } elseif ($action === 'unban_hwid') {
        $hwid = trim($_POST['hwid'] ?? '');
        if ($hwid !== '') ks_unban_hwid($hwid);
    } elseif ($action === 'ban_user') {
        $userId = trim($_POST['ban_user'] ?? '');
        $reason = trim($_POST['ban_reason'] ?? '');
        if ($userId !== '') ks_ban_user($userId, $reason);
    } elseif ($action === 'unban_user') {
        $userId = trim($_POST['userid'] ?? '');
        if ($userId !== '') ks_unban_user($userId);
    }

    header('Location: admin_bans.php');
    exit;
}

$bans = ks_read_bans();

ks_admin_header('bans', 'Bans');
?>

<div class="card">
  <h3 style="margin-top:0">Ban HWID / User (Global)</h3>
  <p class="sub" style="margin-top:-8px">
    Berbeda dari batas per-key (Maks. HWID/User di halaman Keys), ban di sini berlaku LINTAS semua key
    dan produk (termasuk produk Free/Keyless). Sekali di-ban, perangkat/akun itu ditolak di mana pun ia
    mencoba — dan dicek paling awal, sebelum sempat menghabiskan slot HWID/User key mana pun.
  </p>
  <div class="grid">
    <form method="post">
      <input type="hidden" name="action" value="ban_hwid">
      <label>Ban HWID</label>
      <input type="text" name="ban_hwid" placeholder="mis. GUID-perangkat">
      <label>Alasan (opsional)</label>
      <input type="text" name="ban_reason" placeholder="mis. cheating / redistribusi script">
      <button type="submit" class="red">Ban HWID Ini</button>
    </form>
    <form method="post">
      <input type="hidden" name="action" value="ban_user">
      <label>Ban User ID</label>
      <input type="text" name="ban_user" placeholder="mis. 123456789">
      <label>Alasan (opsional)</label>
      <input type="text" name="ban_reason" placeholder="mis. cheating / redistribusi script">
      <button type="submit" class="red">Ban User Ini</button>
    </form>
  </div>
</div>

<div class="card">
  <h3 style="margin-top:0">Daftar yang Di-ban (<?= count($bans['hwids']) + count($bans['users']) ?>)</h3>
  <div class="table-responsive">
  <table>
    <tr><th>Tipe</th><th>ID</th><th>Alasan</th><th>Waktu Ban</th><th>Aksi</th></tr>
    <?php foreach ($bans['hwids'] as $hwid => $info): ?>
    <tr>
      <td><span class="badge revoked">HWID</span></td>
      <td class="key-str"><?= htmlspecialchars($hwid) ?></td>
      <td><?= htmlspecialchars($info['reason'] ?? '') ?></td>
      <td><?= ks_fmt_date($info['banned_at'] ?? null) ?></td>
      <td class="actions">
        <form method="post"><input type="hidden" name="action" value="unban_hwid"><input type="hidden" name="hwid" value="<?= htmlspecialchars($hwid) ?>"><button class="small green">Unban</button></form>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php foreach ($bans['users'] as $userId => $info): ?>
    <tr>
      <td><span class="badge revoked">USER</span></td>
      <td class="key-str"><?= htmlspecialchars($userId) ?></td>
      <td><?= htmlspecialchars($info['reason'] ?? '') ?></td>
      <td><?= ks_fmt_date($info['banned_at'] ?? null) ?></td>
      <td class="actions">
        <form method="post"><input type="hidden" name="action" value="unban_user"><input type="hidden" name="userid" value="<?= htmlspecialchars($userId) ?>"><button class="small green">Unban</button></form>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($bans['hwids']) && empty($bans['users'])): ?>
    <tr><td colspan="5" style="text-align:center; color:var(--muted)">Belum ada yang di-ban.</td></tr>
    <?php endif; ?>
  </table>
  </div>
</div>

<?php ks_admin_footer(); ?>
