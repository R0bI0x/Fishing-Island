<?php
/**
 * admin_logs.php
 * Halaman viewer log aktivitas: validasi key, fetch script, percobaan
 * ditolak, ban/unban, generate key, dsb. Bisa difilter berdasarkan
 * substring nama event.
 */
require_once __DIR__ . '/admin_auth.php';
ks_admin_require_login();

$logFilter = $_GET['log_filter'] ?? '';
$recentLogs = ks_read_recent_logs(LOG_VIEWER_LIMIT, $logFilter);

ks_admin_header('logs', 'Logs');
?>

<div class="card">
  <h3 style="margin-top:0">Log Aktivitas</h3>
  <p class="sub" style="margin-top:-8px">
    Menampilkan <?= LOG_VIEWER_LIMIT ?> entri terakhir (terbaru duluan). Termasuk validasi key, fetch
    script, percobaan yang ditolak, ban/unban, dan aktivitas lainnya.
  </p>
  <form method="get" style="margin-bottom:12px; max-width:260px;">
    <label>Filter Event</label>
    <select name="log_filter" onchange="this.form.submit()">
      <option value="" <?= $logFilter === '' ? 'selected' : '' ?>>Semua</option>
      <option value="fail" <?= $logFilter === 'fail' ? 'selected' : '' ?>>Gagal saja</option>
      <option value="success" <?= $logFilter === 'success' ? 'selected' : '' ?>>Sukses saja</option>
      <option value="free" <?= $logFilter === 'free' ? 'selected' : '' ?>>Free/Keyless saja</option>
      <option value="ban" <?= $logFilter === 'ban' ? 'selected' : '' ?>>Ban/Unban saja</option>
      <option value="generate" <?= $logFilter === 'generate' ? 'selected' : '' ?>>Generate key saja</option>
    </select>
  </form>
  <div class="table-responsive" style="max-height:600px; overflow-y:auto;">
  <table>
    <tr><th>Waktu</th><th>Event</th><th>IP</th><th>Detail</th></tr>
    <?php foreach ($recentLogs as $log): ?>
    <?php
      $detailParts = [];
      foreach ($log as $k => $v) {
          if (in_array($k, ['time', 'event', 'ip'], true)) continue;
          if (is_array($v)) $v = json_encode($v);
          $detailParts[] = $k . '=' . $v;
      }
    ?>
    <tr>
      <td style="white-space:nowrap;"><?= htmlspecialchars($log['time'] ?? '-') ?></td>
      <td><?= htmlspecialchars($log['event'] ?? '-') ?></td>
      <td><?= htmlspecialchars($log['ip'] ?? '-') ?></td>
      <td style="font-size:11px; color:var(--muted); word-break:break-all;"><?= htmlspecialchars(implode(' | ', $detailParts)) ?></td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($recentLogs)): ?>
    <tr><td colspan="4" style="text-align:center; color:var(--muted)">Belum ada log.</td></tr>
    <?php endif; ?>
  </table>
  </div>
</div>

<?php ks_admin_footer(); ?>
