<?php
// Fallback kalau .htaccess (Options -Indexes) diabaikan oleh hosting:
// daripada menampilkan directory listing, arahkan ke panel admin.
header('Location: admin.php');
exit;
