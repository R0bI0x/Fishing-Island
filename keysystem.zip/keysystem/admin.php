<?php
/**
 * admin.php
 * Halaman login. Setelah berhasil login, mengarah ke admin_dashboard.php.
 * Halaman-halaman fitur lain (Keys, Scripts, Bans, Logs) ada di file
 * terpisah masing-masing: admin_keys.php, admin_scripts.php,
 * admin_bans.php, admin_logs.php.
 */
require_once __DIR__ . '/admin_auth.php';

if (isset($_GET['logout'])) {
    ks_admin_logout();
    header('Location: admin.php');
    exit;
}

$error = '';
if (isset($_POST['login'])) {
    $userOk = hash_equals(ADMIN_USERNAME, (string)($_POST['username'] ?? ''));
    $passOk = hash_equals(ADMIN_PASSWORD, (string)($_POST['password'] ?? ''));
    if ($userOk && $passOk) {
        $_SESSION['ks_admin'] = true;
        header('Location: admin_dashboard.php');
        exit;
    }
    $error = 'Username atau password salah.';
}

if (ks_admin_is_logged_in()) {
    header('Location: admin_dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Login - Key System Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="assets/admin.css">
</head>
<body class="login-body">
  <div class="login-wrap card">
    <h1>Key System</h1>
    <p class="sub">Login admin</p>
    <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="post">
      <label>Username</label>
      <input type="text" name="username" required autofocus>
      <label>Password</label>
      <input type="password" name="password" required>
      <button type="submit" name="login" value="1" style="width:100%">Login</button>
    </form>
  </div>
</body>
</html>
