<?php
/**
 * loader_free.php  (STAGE 1 - FREE/KEYLESS)
 *
 * Versi loader.php khusus untuk script yang dibagikan GRATIS (tanpa key).
 * Dipanggil langsung dari:
 *   loadstring(game:HttpGet("https://domainmu.com/keysystem/loader_free.php?product=MyFreeScript"))()
 *
 * Sama seperti loader.php, endpoint ini TIDAK PERNAH mengembalikan isi
 * script asli secara langsung — hanya stub kecil yang menukar dirinya ke
 * api/free_token.php lalu api/get_script.php untuk benar-benar mengambil
 * script. Karena tidak ada key, produk harus lebih dulu ditandai "free"
 * oleh admin di panel (lihat ks_set_product_free()), kalau tidak permintaan
 * ditolak.
 *
 * Proteksi yang tetap berlaku penuh meski tanpa key: rate limit (per-IP dan
 * per-produk), deteksi User-Agent non-Roblox, token sekali-pakai, watermark.
 */

require_once __DIR__ . '/functions.php';
header('Content-Type: text/plain; charset=utf-8'); // override header default JSON dari config.php

$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

// ---- Wajib HTTPS (kalau diaktifkan) ----
if (REQUIRE_HTTPS && !ks_is_https()) {
    ks_log('loader_free_fail', ['reason' => 'not_https', 'ip' => $ip]);
    echo 'error("Akses wajib lewat HTTPS.")';
    exit;
}

// ---- Deteksi User-Agent yang jelas bukan Roblox (curl/bot/stealer generik) ----
if (REQUIRE_ROBLOX_USER_AGENT && !ks_looks_like_roblox_request()) {
    ks_log('loader_free_fail', ['reason' => 'blocked_user_agent', 'ip' => $ip, 'ua' => $_SERVER['HTTP_USER_AGENT'] ?? '']);
    echo 'error("Request ditolak.")';
    exit;
}

// ---- RATE LIMIT berbasis IP ----
if (!ks_rate_limit_check('loaderfree:' . $ip)) {
    ks_log('loader_free_fail', ['reason' => 'rate_limited_ip', 'ip' => $ip]);
    echo 'error("Terlalu banyak permintaan, coba lagi sebentar.")';
    exit;
}

$product = trim($_GET['product'] ?? '');
if ($product === '') {
    echo 'error("Parameter product tidak ditemukan di URL.")';
    exit;
}

// ---- RATE LIMIT TAMBAHAN per-PRODUK (produk free bisa diakses siapa saja) ----
if (!ks_rate_limit_check('loaderfreeproduct:' . $product, FREE_RATE_LIMIT_MAX, FREE_RATE_LIMIT_WINDOW)) {
    ks_log('loader_free_fail', ['product' => $product, 'reason' => 'rate_limited_product', 'ip' => $ip]);
    echo 'error("Terlalu banyak permintaan untuk produk ini. Coba lagi sebentar.")';
    exit;
}

if (!ks_is_product_free($product)) {
    ks_log('loader_free_fail', ['product' => $product, 'reason' => 'not_free_product', 'ip' => $ip]);
    echo 'error("Produk ini tidak tersedia secara gratis.")';
    exit;
}

if (!ks_has_script($product)) {
    echo 'error("Script untuk produk ini belum di-upload admin.")';
    exit;
}

$base = ks_base_url();
$freeTokenUrl = $base . '/api/free_token.php';
$scriptBaseUrl = $base . '/api/get_script.php';

$ticket = REQUIRE_FLOW_TICKET ? ks_issue_flow_ticket($ip) : '';
$ticketLua = ks_lua_escape($ticket);
$productLua = ks_lua_escape($product);

// Stub yang dikirim ke client. Sama seperti versi berkey, cuma memanggil
// free_token.php (tanpa key) alih-alih validate.php. HWID pakai
// RbxAnalyticsService:GetClientId() (persisten per perangkat, tidak
// berubah walau rejoin/pindah server) -- lihat catatan di loader.php.
$stub = <<<LUA
local product = "{$productLua}"
local ticket = "{$ticketLua}"

local userid, hwid
do
    local ok, uid = pcall(function()
        local plr = game:GetService("Players").LocalPlayer
        return plr and plr.UserId or 0
    end)
    userid = ok and tostring(uid) or "unknown-user"

    local hwidOk, clientId = pcall(function()
        return game:GetService("RbxAnalyticsService"):GetClientId()
    end)
    if hwidOk and clientId and clientId ~= "" then
        hwid = clientId
    else
        hwid = "uid-" .. userid
    end
end

local Http = game:GetService("HttpService")

local function urlencode(str)
    str = tostring(str)
    str = str:gsub("([^%w%-%.%_%~])", function(c)
        return string.format("%%%02X", string.byte(c))
    end)
    return str
end

local tokenUrl = "{$freeTokenUrl}?product=" .. urlencode(product) .. "&hwid=" .. urlencode(hwid) .. "&userid=" .. urlencode(userid) .. "&ticket=" .. urlencode(ticket)
local ok2, resp = pcall(function() return game:HttpGet(tokenUrl) end)
if not ok2 then
    return error("Gagal menghubungi server key system.")
end

local ok4, data = pcall(function() return Http:JSONDecode(resp) end)
if not ok4 or type(data) ~= "table" then
    return error("Respon server tidak valid.")
end
if not data.success then
    return error("Gagal memuat script: " .. tostring(data.message))
end
if not data.data or not data.data.script_token then
    return error("Script belum tersedia untuk produk ini.")
end

local scriptUrl = "{$scriptBaseUrl}?raw=1&token=" .. urlencode(data.data.script_token)
local ok3, code = pcall(function() return game:HttpGet(scriptUrl) end)
if not ok3 then
    return error("Gagal mengambil script.")
end

local fn = loadstring(code)
if not fn then
    return error("Script tidak valid / gagal dimuat.")
end
return fn()
LUA;

ks_log('loader_free_stub_issued', ['product' => $product, 'ip' => $ip]);

echo $stub;
