<?php
/**
 * admin_scripts.php
 * Halaman manajemen script terenkripsi: upload lewat FILE (default, cukup
 * isi nama produk + pilih file, tanpa copy-paste) atau tempel kode manual
 * (opsi lanjutan), lihat daftar produk yang sudah punya script, dan toggle
 * status Free/Keyless per produk.
 */
require_once __DIR__ . '/admin_auth.php';
ks_admin_require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'upload_script_file') {
        $product = trim($_POST['script_product'] ?? '');
        $file    = $_FILES['script_file'] ?? null;
        $maxUploadBytes = 2 * 1024 * 1024; // 2MB, cukup longgar untuk script Lua
        if ($product !== '' && $file && ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            if ($file['size'] > 0 && $file['size'] <= $maxUploadBytes && is_uploaded_file($file['tmp_name'])) {
                $code = file_get_contents($file['tmp_name']);
                if ($code !== false && trim($code) !== '') {
                    ks_save_script($product, $code);
                }
            }
        }
    } elseif ($action === 'upload_script') {
        $product = trim($_POST['script_product'] ?? '');
        $code    = $_POST['script_code'] ?? '';
        if ($product !== '' && $code !== '') {
            ks_save_script($product, $code);
        }
    } elseif ($action === 'toggle_free') {
        $product = trim($_POST['product'] ?? '');
        $enabled = isset($_POST['enabled']) && $_POST['enabled'] === '1';
        if ($product !== '') ks_set_product_free($product, $enabled);
    }

    header('Location: admin_scripts.php');
    exit;
}

$scriptProducts = ks_list_script_products();

ks_admin_header('scripts', 'Scripts');
?>

<div class="card">
  <h3 style="margin-top:0">Kelola Script (Terenkripsi)</h3>
  <p class="sub" style="margin-top:-8px">
    Script yang di-upload di sini disimpan <b>terenkripsi (AES-256)</b> di server dan tidak bisa diakses
    langsung lewat URL. Script hanya dikeluarkan lewat alur loadstring 2-tahap setelah key + HWID
    milik pemakai tervalidasi, dan otomatis dibubuhi watermark jejak key supaya kalau bocor bisa dilacak.
    Setiap produk juga bisa ditandai <b>Free/Keyless</b> (lihat tabel di bawah) supaya bisa dipakai tanpa
    key sama sekali — proteksi lain (2-tahap, rate limit, token sekali-pakai, watermark) tetap berlaku penuh.
  </p>

  <div class="tabs">
    <button type="button" class="tab-btn active" data-tab-group="scriptUpload" data-tab-name="file" onclick="ksSwitchTab('file','scriptUpload')">Upload File</button>
    <button type="button" class="tab-btn" data-tab-group="scriptUpload" data-tab-name="paste" onclick="ksSwitchTab('paste','scriptUpload')">Tempel Kode (Lanjutan)</button>
  </div>

  <div class="tab-panel active" data-tab-group="scriptUpload" data-tab-name="file">
    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="action" value="upload_script_file">
      <label>Nama Produk (harus sama persis dengan field "product" saat generate key)</label>
      <input type="text" name="script_product" placeholder="MyScript" required>
      <label>File Script (.lua, .luau, .txt)</label>
      <input type="file" name="script_file" accept=".lua,.luau,.txt" required>
      <button type="submit">Upload &amp; Enkripsi Script</button>
    </form>
  </div>

  <div class="tab-panel" data-tab-group="scriptUpload" data-tab-name="paste">
    <form method="post">
      <input type="hidden" name="action" value="upload_script">
      <label>Nama Produk (harus sama persis dengan field "product" saat generate key)</label>
      <input type="text" name="script_product" placeholder="MyScript" required>
      <label>Isi Script (source code asli)</label>
      <textarea name="script_code" rows="10" required style="font-family:monospace; font-size:13px;" placeholder="-- source code kamu di sini"></textarea>
      <button type="submit">Simpan &amp; Enkripsi Script</button>
    </form>
  </div>
</div>

<div class="card">
  <h3 style="margin-top:0">Produk Ter-upload (<?= count($scriptProducts) ?>)</h3>
  <div class="table-responsive">
  <table>
    <tr><th>Produk</th><th>Ukuran</th><th>Terakhir diupdate</th><th>Status Akses</th><th>Aksi</th></tr>
    <?php foreach ($scriptProducts as $pname => $info): ?>
    <?php $isFree = ks_is_product_free($pname); ?>
    <tr>
      <td><?= htmlspecialchars($pname) ?></td>
      <td><?= number_format($info['bytes']) ?> bytes</td>
      <td><?= ks_fmt_date($info['updated_at']) ?></td>
      <td>
        <?php if ($isFree): ?>
          <span class="badge active">FREE / KEYLESS</span>
        <?php else: ?>
          <span class="badge revoked">Wajib Key</span>
        <?php endif; ?>
      </td>
      <td class="actions">
        <form method="post" style="display:inline">
          <input type="hidden" name="action" value="toggle_free">
          <input type="hidden" name="product" value="<?= htmlspecialchars($pname) ?>">
          <input type="hidden" name="enabled" value="<?= $isFree ? '0' : '1' ?>">
          <button type="submit" class="small <?= $isFree ? 'red' : 'green' ?>">
            <?= $isFree ? 'Jadikan Wajib Key' : 'Jadikan Free/Keyless' ?>
          </button>
        </form>
        <?php if ($isFree): ?>
        <?php $freeRowId = 'lsfree_' . md5($pname); ?>
        <div style="margin-top:6px;">
          <input type="text" readonly value="<?= htmlspecialchars(ks_build_free_loadstring($pname)) ?>" id="<?= $freeRowId ?>" style="width:160px; font-size:11px; margin-bottom:4px;">
          <button type="button" class="small" onclick="copyField('<?= $freeRowId ?>')">Copy Loadstring</button>
        </div>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if (empty($scriptProducts)): ?>
    <tr><td colspan="5" style="text-align:center; color:var(--muted)">Belum ada script ter-upload.</td></tr>
    <?php endif; ?>
  </table>
  </div>
</div>

<?php ks_admin_footer(); ?>
