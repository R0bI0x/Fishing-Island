<?php
/**
 * admin_auth.php
 * Fungsi bersama untuk semua halaman panel admin: session, cek login,
 * dan layout header/footer (navbar responsif) yang dipakai tiap halaman
 * supaya tampilannya konsisten tanpa duplikasi HTML di setiap file.
 */

require_once __DIR__ . '/functions.php';

// Halaman ini menghasilkan HTML, jadi WAJIB override Content-Type default
// (application/json) dari config.php -- kalau tidak browser menampilkan
// HTML mentah sebagai teks alih-alih merendernya.
header('Content-Type: text/html; charset=utf-8');
session_start();

function ks_admin_is_logged_in() {
    return !empty($_SESSION['ks_admin']);
}

/**
 * Panggil di awal setiap halaman admin (selain admin.php sendiri) untuk
 * memastikan hanya admin yang login yang bisa mengakses.
 */
function ks_admin_require_login() {
    if (!ks_admin_is_logged_in()) {
        header('Location: admin.php');
        exit;
    }
}

function ks_admin_logout() {
    $_SESSION = [];
    session_destroy();
}

function ks_fmt_date($ts) {
    return $ts ? date('d-m-Y H:i', $ts) : '-';
}

/**
 * Render bagian atas halaman (head + navbar responsif + buka <main>).
 * $activePage salah satu dari: dashboard, keys, scripts, bans, logs.
 */
function ks_admin_header($activePage, $title) {
    $navItems = [
        'dashboard' => ['admin_dashboard.php', 'Dashboard'],
        'keys'      => ['admin_keys.php', 'Keys'],
        'scripts'   => ['admin_scripts.php', 'Scripts'],
        'bans'      => ['admin_bans.php', 'Bans'],
        'logs'      => ['admin_logs.php', 'Logs'],
    ];
    ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($title) ?> - Key System Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<input type="checkbox" id="navToggle" class="nav-toggle-checkbox">
<div class="navbar">
  <div class="navbar-brand">Key System</div>
  <label for="navToggle" class="navbar-burger" aria-label="Buka menu">&#9776;</label>
  <nav class="navbar-links">
    <?php foreach ($navItems as $pageKey => $item): ?>
      <a href="<?= htmlspecialchars($item[0]) ?>" class="<?= $activePage === $pageKey ? 'active' : '' ?>"><?= htmlspecialchars($item[1]) ?></a>
    <?php endforeach; ?>
    <a href="admin.php?logout=1" class="logout-link">Logout</a>
  </nav>
</div>
<main class="container">
<h1><?= htmlspecialchars($title) ?></h1>
    <?php
}

/**
 * Render bagian bawah halaman (tutup <main> + script bersama).
 */
function ks_admin_footer() {
    ?>
</main>
<script>
function copyField(id) {
  var el = document.getElementById(id);
  el.select();
  el.setSelectionRange(0, 99999);
  if (navigator.clipboard) {
    navigator.clipboard.writeText(el.value).catch(function () {
      document.execCommand('copy');
    });
  } else {
    document.execCommand('copy');
  }
}
function ksSwitchTab(tabName, groupName) {
  document.querySelectorAll('[data-tab-group="' + groupName + '"]').forEach(function (el) {
    el.classList.toggle('active', el.getAttribute('data-tab-name') === tabName);
  });
}
</script>
</body>
</html>
    <?php
}
