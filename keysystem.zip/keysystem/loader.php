<?php
/**
 * loader.php  (STAGE 1)
 *
 * Ini SATU-SATUNYA endpoint yang dipanggil langsung dari:
 *   loadstring(game:HttpGet("https://domainmu.com/keysystem/loader.php?key=XXXX-XXXX-XXXX-XXXX"))()
 *
 * Endpoint ini SENGAJA TIDAK PERNAH mengembalikan isi script asli.
 * Yang dikembalikan hanyalah "stub" Lua kecil yang, saat dijalankan oleh
 * client (di dalam Roblox/executor), akan:
 *   1. Menghitung HWID/identitas asli perangkat/akun yang menjalankannya
 *   2. Memanggil api/validate.php lalu api/get_script.php (STAGE 2) membawa
 *      key + hwid tersebut
 *   3. loadstring() hasilnya (baru di titik inilah script asli benar-benar
 *      terpasang di memori, hanya untuk request yang HWID-nya sudah terikat)
 *
 * Kenapa ini lebih aman dibanding kasih script langsung di stage ini:
 *   - URL loadstring yang dibagikan pengguna bersifat statis, tapi isinya
 *     yang keluar dari sini HANYA stub pendek, bukan script -> kalau URL
 *     ini sendiri bocor/dicoba orang lain, mereka cuma dapat stub kosong,
 *     bukan script.
 *   - Script asli baru pernah keluar dari server setelah HWID pemanggil
 *     terverifikasi di stage 2, dan setiap kali keluar selalu versi
 *     ter-watermark (tidak ada satu file statis yang bisa disimpan/
 *     disebarluaskan sebagai "hasil scrape").
 */

require_once __DIR__ . '/functions.php';
header('Content-Type: text/plain; charset=utf-8'); // override header default JSON dari config.php

$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

// ---- Wajib HTTPS (cegah key disadap di jaringan) ----
if (REQUIRE_HTTPS && !ks_is_https()) {
    ks_log('loader_fail', ['reason' => 'not_https', 'ip' => $ip]);
    echo 'error("Akses wajib lewat HTTPS.")';
    exit;
}

// ---- Deteksi User-Agent yang jelas bukan Roblox (curl/bot/stealer generik) ----
if (REQUIRE_ROBLOX_USER_AGENT && !ks_looks_like_roblox_request()) {
    ks_log('loader_fail', ['reason' => 'blocked_user_agent', 'ip' => $ip, 'ua' => $_SERVER['HTTP_USER_AGENT'] ?? '']);
    echo 'error("Request ditolak.")';
    exit;
}

// ---- RATE LIMIT berbasis IP ----
if (!ks_rate_limit_check('loader:' . $ip)) {
    ks_log('loader_fail', ['reason' => 'rate_limited_ip', 'ip' => $ip]);
    echo 'error("Terlalu banyak permintaan, coba lagi sebentar.")';
    exit;
}

$key = trim($_GET['key'] ?? '');
if ($key === '') {
    echo 'error("Key tidak ditemukan di URL.")';
    exit;
}

// ---- RATE LIMIT TAMBAHAN berbasis KEY (menahan botnet lintas-IP yang pakai 1 key curian) ----
if (!ks_rate_limit_check('loaderkey:' . $key, KEY_RATE_LIMIT_MAX, KEY_RATE_LIMIT_WINDOW)) {
    ks_log('loader_fail', ['key' => $key, 'reason' => 'rate_limited_key', 'ip' => $ip]);
    echo 'error("Terlalu banyak permintaan untuk key ini. Coba lagi sebentar.")';
    exit;
}

// Pre-check key TANPA hwid dulu (hwid belum kita tahu di stage ini) -
// cukup pastikan key memang ada, statusnya aktif, dan belum expired.
$precheck = ks_validate_key($key, '', null);
if (!$precheck['success']) {
    ks_log('loader_fail', ['key' => $key, 'reason' => $precheck['message']]);
    echo 'error(' . var_export($precheck['message'], true) . ')';
    exit;
}

$product = $precheck['data']['product'];

if (!ks_has_script($product)) {
    echo 'error("Script untuk produk ini belum di-upload admin.")';
    exit;
}

$base = ks_base_url();
$validateUrl = $base . '/api/validate.php';
$scriptBaseUrl = $base . '/api/get_script.php';

// Terbitkan flow ticket: bukti bahwa permintaan ini benar-benar melalui
// loader.php lebih dulu (bukan langsung curl ke validate.php dengan
// User-Agent Roblox palsu). Berumur pendek & sekali-pakai.
$ticket = REQUIRE_FLOW_TICKET ? ks_issue_flow_ticket($ip) : '';
$ticketLua = ks_lua_escape($ticket);

$keyLua     = ks_lua_escape($key);
$productLua = ks_lua_escape($product);

// Stub yang dikirim ke client. Stub ini menghitung hwid dari sisi client,
// menukarnya ke validate.php untuk dapat token sekali-pakai, lalu menukar
// token itu ke get_script.php untuk benar-benar mengambil script asli.
//
// PENTING soal HWID: hwid HARUS berupa ID yang persisten per PERANGKAT,
// bukan per SESI. Sebelumnya kode ini memakai kombinasi UserId+JobId, tapi
// JobId adalah ID server Roblox yang GANTI setiap kali pemain rejoin/pindah
// server -- akibatnya perangkat yang sama dianggap "perangkat baru" tiap
// sesi, cepat menghabiskan kuota max_hwid, dan mengunci pemain sah sendiri.
// Sekarang dipakai RbxAnalyticsService:GetClientId(), ID yang persisten per
// perangkat/instalasi Roblox (tidak berubah walau rejoin/pindah server),
// dengan fallback ke UserId kalau API itu gagal diakses.
$stub = <<<LUA
local key = "{$keyLua}"
local product = "{$productLua}"
local ticket = "{$ticketLua}"

local userid, hwid
do
    local ok, uid = pcall(function()
        local plr = game:GetService("Players").LocalPlayer
        return plr and plr.UserId or 0
    end)
    userid = ok and tostring(uid) or "unknown-user"

    local hwidOk, clientId = pcall(function()
        return game:GetService("RbxAnalyticsService"):GetClientId()
    end)
    if hwidOk and clientId and clientId ~= "" then
        hwid = clientId
    else
        -- fallback: kalau GetClientId gagal (executor tidak mendukung/API
        -- diblokir), pakai UserId saja supaya minimal tetap konsisten per
        -- akun antar sesi, meski tidak seketat per-perangkat.
        hwid = "uid-" .. userid
    end
end

local Http = game:GetService("HttpService")

-- Percent-encode supaya key/hwid/userid/product yang mengandung spasi atau
-- karakter simbol tidak merusak query string URL.
local function urlencode(str)
    str = tostring(str)
    str = str:gsub("([^%w%-%.%_%~])", function(c)
        return string.format("%%%02X", string.byte(c))
    end)
    return str
end

local validateUrl = "{$validateUrl}?key=" .. urlencode(key) .. "&hwid=" .. urlencode(hwid) .. "&userid=" .. urlencode(userid) .. "&product=" .. urlencode(product) .. "&ticket=" .. urlencode(ticket)
local ok2, resp = pcall(function() return game:HttpGet(validateUrl) end)
if not ok2 then
    return error("Gagal menghubungi server key system.")
end

local ok4, data = pcall(function() return Http:JSONDecode(resp) end)
if not ok4 or type(data) ~= "table" then
    return error("Respon server tidak valid.")
end
if not data.success then
    return error("Key gagal divalidasi: " .. tostring(data.message))
end
if not data.data or not data.data.script_token then
    return error("Script belum tersedia untuk produk ini.")
end

local scriptUrl = "{$scriptBaseUrl}?raw=1&token=" .. urlencode(data.data.script_token)
local ok3, code = pcall(function() return game:HttpGet(scriptUrl) end)
if not ok3 then
    return error("Gagal mengambil script.")
end

local fn = loadstring(code)
if not fn then
    return error("Script tidak valid / gagal dimuat.")
end
return fn()
LUA;

ks_log('loader_stub_issued', ['key' => $key, 'product' => $product, 'ip' => $ip]);

echo $stub;
