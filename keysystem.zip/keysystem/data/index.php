<?php
// Folder ini seharusnya sudah diblokir total oleh .htaccess (Require all
// denied). File ini cuma lapisan tambahan kalau .htaccess diabaikan hosting.
http_response_code(403);
exit;
