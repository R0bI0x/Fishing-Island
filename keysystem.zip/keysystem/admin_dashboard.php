<?php
/**
 * admin_dashboard.php
 * Halaman analytics/ringkasan: total key per status, total produk script,
 * total produk free/keyless, total ban, dan aktivitas terbaru (hari ini /
 * 7 hari terakhir) beserta 10 jenis event paling sering muncul. Semua
 * dihitung dari data yang sudah ada (keys.json, bans.json, logs.json,
 * script_index.json, free_products.json) -- tidak ada tracker pihak
 * ketiga, semuanya self-hosted dari log milik sistem sendiri.
 */
require_once __DIR__ . '/admin_auth.php';
ks_admin_require_login();

$keysData = ks_read_keys()['keys'];
$totalKeys = count($keysData);

$statusCounts = ['active' => 0, 'revoked' => 0, 'paused' => 0, 'expired' => 0];
foreach ($keysData as $k) {
    $s = $k['status'] ?? 'active';
    if (!isset($statusCounts[$s])) $statusCounts[$s] = 0;
    $statusCounts[$s]++;
}

$scriptProducts = ks_list_script_products();
$totalScripts = count($scriptProducts);

$freeProducts = ks_read_free_products();
$totalFree = count($freeProducts);

$bans = ks_read_bans();
$totalBannedHwid = count($bans['hwids']);
$totalBannedUser = count($bans['users']);

// Ambil sampel log lebih besar dari batas viewer biasa, khusus untuk hitungan statistik
$analyticsLogs = ks_read_recent_logs(2000);

$eventCounts = [];
$todayCount = 0;
$weekCount = 0;
$todayStr = date('Y-m-d');
$weekAgo = strtotime('-7 days');

foreach ($analyticsLogs as $log) {
    $ev = $log['event'] ?? 'unknown';
    $eventCounts[$ev] = ($eventCounts[$ev] ?? 0) + 1;
    $t = isset($log['time']) ? strtotime($log['time']) : false;
    if ($t !== false) {
        if (date('Y-m-d', $t) === $todayStr) $todayCount++;
        if ($t >= $weekAgo) $weekCount++;
    }
}
arsort($eventCounts);
$topEvents = array_slice($eventCounts, 0, 10, true);
$maxEventCount = !empty($topEvents) ? max($topEvents) : 1;

ks_admin_header('dashboard', 'Dashboard');
?>

<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-value"><?= $totalKeys ?></div>
    <div class="stat-label">Total Key</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= $statusCounts['active'] ?></div>
    <div class="stat-label">Key Aktif</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= $totalScripts ?></div>
    <div class="stat-label">Produk Script</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= $totalFree ?></div>
    <div class="stat-label">Free / Keyless</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= $totalBannedHwid + $totalBannedUser ?></div>
    <div class="stat-label">Total Ban (HWID+User)</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= $todayCount ?></div>
    <div class="stat-label">Aktivitas Hari Ini</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= $weekCount ?></div>
    <div class="stat-label">Aktivitas 7 Hari</div>
  </div>
</div>

<div class="card">
  <h3 style="margin-top:0">Status Key</h3>
  <?php if ($totalKeys === 0): ?>
  <p class="sub">Belum ada key. Buat key pertama di halaman <a href="admin_keys.php">Keys</a>.</p>
  <?php else: ?>
  <div class="bar-list">
    <?php foreach ($statusCounts as $status => $count): ?>
    <?php $pct = $totalKeys > 0 ? round($count / $totalKeys * 100) : 0; ?>
    <div class="bar-row">
      <div class="bar-label"><?= htmlspecialchars(ucfirst($status)) ?> (<?= $count ?>)</div>
      <div class="bar-track"><div class="bar-fill status-<?= htmlspecialchars($status) ?>" style="width:<?= $pct ?>%"></div></div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<div class="card">
  <h3 style="margin-top:0">10 Event Teratas</h3>
  <p class="sub" style="margin-top:-8px">Dihitung dari sampel <?= count($analyticsLogs) ?> log terakhir. Lihat detail lengkap di halaman <a href="admin_logs.php">Logs</a>.</p>
  <?php if (empty($topEvents)): ?>
  <p class="sub">Belum ada data log.</p>
  <?php else: ?>
  <div class="bar-list">
    <?php foreach ($topEvents as $ev => $count): ?>
    <?php $pct = round($count / $maxEventCount * 100); ?>
    <div class="bar-row">
      <div class="bar-label"><?= htmlspecialchars($ev) ?> (<?= $count ?>)</div>
      <div class="bar-track"><div class="bar-fill" style="width:<?= $pct ?>%"></div></div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<?php ks_admin_footer(); ?>
