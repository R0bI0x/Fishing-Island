<?php
/**
 * contoh-client.php
 * Contoh cara MEMANGGIL endpoint validate.php dari aplikasi/script lain (PHP)
 * UNTUK SEKADAR CEK VALIDITAS KEY (tanpa mengambil script).
 *
 * CATATAN PENTING #1: secara default REQUIRE_ROBLOX_USER_AGENT di config.php
 * aktif, jadi endpoint akan menolak request yang User-Agent-nya bukan dari
 * Roblox. Di bawah kita kirim header User-Agent "Roblox/WinInet" khusus
 * SUPAYA CONTOH INI BISA DIPAKAI UNTUK TESTING.
 *
 * CATATAN PENTING #2: sejak fitur flow ticket ditambahkan, memanggil
 * validate.php LANGSUNG seperti contoh ini TIDAK AKAN PERNAH mendapatkan
 * "script_token" — itu memang disengaja. script_token hanya diterbitkan
 * untuk permintaan yang tiketnya berasal dari loader.php (yang otomatis
 * dijalankan Roblox lewat loadstring, bukan dipanggil manual seperti ini).
 * Contoh ini karena itu HANYA mendemonstrasikan pengecekan validitas key —
 * bukan alur pengambilan script. Untuk mengetes alur script yang
 * sesungguhnya, jalankan loadstring-nya dari dalam Roblox/executor.
 */

$endpoint = 'https://domainmu.com/keysystem/api/validate.php';

$key     = 'ABCD-1234-EFGH-5678'; // key yang dimasukkan user
$hwid    = md5(php_uname());       // contoh sederhana bikin id unik perangkat
$userId  = 'user_123';             // opsional: ID user/akun (independen dari hwid, untuk batas max_user)
$product = 'MyScript';

$url = $endpoint . '?' . http_build_query([
    'key'     => $key,
    'hwid'    => $hwid,
    'userid'  => $userId,
    'product' => $product,
]);

// User-Agent testing supaya lolos cek REQUIRE_ROBLOX_USER_AGENT (lihat catatan di atas)
$context = stream_context_create([
    'http' => ['header' => "User-Agent: Roblox/WinInet\r\n"],
]);
$response = file_get_contents($url, false, $context);
$result = json_decode($response, true);

if ($result && $result['success']) {
    echo "Key valid! Produk: " . $result['data']['product'] . "\n";
    if ($result['data']['lifetime']) {
        echo "Key ini lifetime (tidak pernah expired).\n";
    } else {
        echo "Berlaku sampai: " . date('d-m-Y H:i', $result['data']['expires_at']) . "\n";
    }

    if (isset($result['data']['script_token'])) {
        // Ini seharusnya TIDAK PERNAH terjadi kalau REQUIRE_FLOW_TICKET aktif
        // dan panggilan ini datang tanpa tiket dari loader.php.
        echo "(tidak terduga) script_token ikut terbit meski tanpa flow ticket.\n";
    } else {
        echo "Key tervalidasi, tapi script_token TIDAK diterbitkan -- ini normal,\n";
        echo "karena permintaan ini tidak melalui loader.php. Untuk benar-benar\n";
        echo "mengambil script, jalankan loadstring-nya dari dalam Roblox.\n";
    }
} else {
    echo "Key tidak valid: " . ($result['message'] ?? 'Unknown error') . "\n";
}
